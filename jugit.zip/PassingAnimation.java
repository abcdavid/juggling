import java.awt.*;
import java.util.Enumeration;

import animation.*;
import juggling.*;

public class PassingAnimation extends JugglingAnimation {
	Point[] handCatchPoints;
	Point[] handPassPoints;

	public PassingAnimation(PatternController patternController) {
		super(patternController);
	}
	public void initAnimation() {
		// calculate positions of hands
		Pattern pattern=patternController.getPattern();
		handPassPoints=new Point[pattern.getHandCount()];
		handCatchPoints=new Point[pattern.getHandCount()];
		// position jugglers in circle
		double radius=(double)((Math.min(getSize().width,getSize().height)-getBallRadius()*3)/2);// the radius of the circle of jugglers
		double handSeparation=Math.PI/18.0d; // (2*handSeparation) ~=20 degrees between hands
		double handCatchSeparation=Math.PI/18.0d; // ~=20 degrees between catch and throw points
		double radianSeparation=(2.0d*Math.PI)/(double)pattern.getJugglerCount();
		double rads=0.0d;
		double x,y;
		for (int j=0;j<pattern.getJugglerCount();j++) {
			// throw on inside, catche on outside
			double rRads=rads-handSeparation;
			double lRads=rads+handSeparation;
			double rRadsCatch=rRads-handCatchSeparation;
			double lRadsCatch=lRads+handCatchSeparation;
			x=radius*Math.cos(rRads);
			y=radius*Math.sin(rRads);
			handPassPoints[2*j]=new Point((int)x,(int)y);
			handPassPoints[2*j].translate(getSize().width/2,getSize().height/2);
			x=radius*Math.cos(rRadsCatch);
			y=radius*Math.sin(rRadsCatch);
			handCatchPoints[2*j]=new Point((int)x,(int)y);
			handCatchPoints[2*j].translate(getSize().width/2,getSize().height/2);
			x=radius*Math.cos(lRadsCatch);
			y=radius*Math.sin(lRadsCatch);
			handCatchPoints[2*j+1]=new Point((int)x,(int)y);
			handCatchPoints[2*j+1].translate(getSize().width/2,getSize().height/2);
			x=radius*Math.cos(lRads);
			y=radius*Math.sin(lRads);
			handPassPoints[2*j+1]=new Point((int)x,(int)y);
			handPassPoints[2*j+1].translate(getSize().width/2,getSize().height/2);
			rads+=radianSeparation;
		}
	}
	public void render(Graphics g,long time) {
		drawHands(g);
		long beatNo=time/getBeatTime();
		long remainder=time%getBeatTime();
		Enumeration enum=patternController.getPattern().getPassingEndPoints((int)beatNo);
		while (enum.hasMoreElements()) {
			EndPoint passPoint=(EndPoint)enum.nextElement();
			EndPoint catchPoint=passPoint.getPassDestination();
			// calculate fraction of pass which has elapsed
			// how many beats since pass
			long wholeBeats=beatNo-(long)passPoint.getTime();
			long totalPassTime=(long)(catchPoint.getTime()-passPoint.getTime())*getBeatTime();
			long elapsedPassTime=(long)wholeBeats*getBeatTime()+remainder;
			long handTime=getHandTime(catchPoint.getTime()-passPoint.getTime());
			double passFraction;
			Point fromPoint,toPoint;
			// is ball in air?
			if (elapsedPassTime>(totalPassTime-handTime)) {
				// in hand
				passFraction=(double)(elapsedPassTime-(totalPassTime-handTime))/(double)handTime;
				fromPoint=handCatchPoints[catchPoint.getHand().getNumber()];
				toPoint=handPassPoints[catchPoint.getHand().getNumber()];
			} else {
				// in air
				passFraction=(double)elapsedPassTime/(double)(totalPassTime-handTime);
				fromPoint=handPassPoints[passPoint.getHand().getNumber()];
				toPoint=handCatchPoints[catchPoint.getHand().getNumber()];
			}
			int x=fromPoint.x+(int)((double)(toPoint.x-fromPoint.x)*passFraction);
			int y=fromPoint.y+(int)((double)(toPoint.y-fromPoint.y)*passFraction);
			drawBall(g,x,y,passPoint.getBall());
		}
	}
	protected void drawHands(Graphics g) {
		// simple crosses
		g.setColor(Color.black);
		for (int i=0;i<handPassPoints.length;i++) {
			drawHand(g,handPassPoints[i]);
			drawHand(g,handCatchPoints[i]);
		}
	}
}
