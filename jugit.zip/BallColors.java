import juggling.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class BallColors extends Dialog {
	PatternController patternController;
	BallColor editingBall;
	
	static void showColorsDialog(Frame parent,PatternController patternController) {
		BallColors colors=new BallColors(parent,"Ball Colours",true,patternController);
		colors.setVisible(true);
	}
	private BallColors(Frame parent,String title,boolean modal,PatternController patternController) {
		super(parent,title,modal);
		this.patternController=patternController;
		setBackground(Color.white);
		initBallColors(patternController.getPattern());
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				setVisible(false);
				dispose();
			}
		});
		if (parent!=null) {
			Point location=parent.getLocation();
			location.translate(parent.getSize().width/2-getSize().width/2,parent.getSize().height/2-getSize().height/2);
			setLocation(location);
		}
	}
	private void initBallColors(Pattern pattern) {
		int count=pattern.getBallCount();
		int height=0;
		
		setLayout(new GridBagLayout());
		GridBagConstraints gbConstraints=new GridBagConstraints();
		
		BallColor firstBallColor=null;
		for (int i=0;i<count;i++) {
			BallColor ballColor=new BallColor(pattern.getBall(i));
			if (i==0) firstBallColor=ballColor;
			gbConstraints.fill=gbConstraints.HORIZONTAL;
			gbConstraints.anchor=gbConstraints.CENTER;
			gbConstraints.gridy=i;
			gbConstraints.gridwidth=2;
			add(ballColor,gbConstraints);
			height+=ballColor.getSize().height;
		}
		ActionListener actionListener=new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((TextField)e.getSource()).transferFocus();
			}
		};
		FocusListener focusListener=new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				updateColor();
			}
		};
		
		Label label=new Label("Red");
		gbConstraints.gridy=count;
		gbConstraints.gridwidth=1;
		add(label,gbConstraints);

		redText=new TextField(3);
		redText.setEnabled(false);
		redText.addActionListener(actionListener);
		redText.addFocusListener(focusListener);
		gbConstraints.gridy=count++;
		gbConstraints.gridwidth=1;
		add(redText,gbConstraints);

		label=new Label("Green");
		gbConstraints.gridy=count;
		gbConstraints.gridwidth=1;
		add(label,gbConstraints);

		greenText=new TextField(3);
		greenText.setEnabled(false);
		greenText.addActionListener(actionListener);
		greenText.addFocusListener(focusListener);
		gbConstraints.gridy=count++;
		gbConstraints.gridwidth=1;
		add(greenText,gbConstraints);

		label=new Label("Blue");
		gbConstraints.gridy=count;
		gbConstraints.gridwidth=1;
		add(label,gbConstraints);

		blueText=new TextField(3);
		blueText.setEnabled(false);
		blueText.addActionListener(actionListener);
		blueText.addFocusListener(focusListener);
		gbConstraints.gridy=count++;
		gbConstraints.gridwidth=1;
		add(blueText,gbConstraints);
		
		Button okButton=new Button("OK");
		gbConstraints.gridy=count;
		gbConstraints.anchor=gbConstraints.CENTER;
		gbConstraints.gridwidth=2;
		gbConstraints.fill=gbConstraints.NONE;
		add(okButton,gbConstraints);
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		pack();
		setResizable(false);
		if (firstBallColor!=null) editBall(firstBallColor);
	}
	private void editBall(BallColor ballColor) {
		if (editingBall!=null && !editingBall.equals(ballColor)) {
			updateColor(); // ensure changes not lost
			editingBall.isSelected=false;
			editingBall.repaint();
		}
		editingBall=ballColor;
		editingBall.isSelected=true;
		Color color=patternController.getBallColor(ballColor.ball);
		redText.setText(Integer.toString(color.getRed()));
		redText.setEnabled(true);
		greenText.setText(Integer.toString(color.getGreen()));
		greenText.setEnabled(true);
		blueText.setText(Integer.toString(color.getBlue()));
		blueText.setEnabled(true);
		editingBall.repaint();
	}
	private void updateColor() {
		if (editingBall!=null) {
			try {
				int red=Integer.valueOf(redText.getText()).intValue();
				int green=Integer.valueOf(greenText.getText()).intValue();
				int blue=Integer.valueOf(blueText.getText()).intValue();
				if (red>=0 && red<=255 && green>=0 && green<=255 && blue>=0 && blue<=255) {
					patternController.setBallColor(editingBall.ball,new Color(red,green,blue));
					editingBall.repaint();
				} else {
					editBall(editingBall); // resets text
					Thread thread=new Thread() {
						public void run() {
							MessageDialog.showMessageDialog(BallColors.this,"Colour change","Values should be between 0 and 255",MessageDialog.OK);
						}
					};
					thread.start();
				}
			} catch (NumberFormatException e) {
				editBall(editingBall); // resets text
				Thread thread=new Thread() {
					public void run() {
						MessageDialog.showMessageDialog(BallColors.this,"Colour change","Please enter a number between 0 and 255",MessageDialog.OK);
					}
				};
				thread.start();
			}
		}
	}

	TextField redText;
	TextField greenText;
	TextField blueText;
	
	class BallColor extends Canvas {
		Ball ball;
		int radius=10;
		boolean isSelected=false;
		
		BallColor(Ball ball) {
			this.ball=ball;
			addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					editBall(BallColor.this);
				}
			});
		}
		public Dimension getPreferredSize() {
			return new Dimension(100,radius*2);
		}
		public void paint(Graphics g) {
			if (isSelected) g.setColor(Color.lightGray);
			else g.setColor(Color.white);
			g.fillRect(0,0,getSize().width,getSize().height);
			g.setColor(patternController.getBallColor(ball));
			g.fillOval(0,0,radius*2,radius*2);
			g.setColor(Color.black);
			String label="Ball "+Integer.toString(ball.getNumber()+1);
			g.drawString("Ball "+(ball.getNumber()+1),radius*3,radius+g.getFontMetrics().getHeight()/2);
		}
		
	}
}
