import java.util.*;
import java.io.*;
import java.awt.Color;

import juggling.*;

public class PatternController extends Observable {

	static FileFormat fileFormat=new PatternFileFormat();
	static int untitledCount=0;
	
	String filename;
	File patternFile;
	Pattern pattern;
	Stack undoStack=new Stack();
	Stack redoStack=new Stack();
	int changeCount=0;
	boolean multipleChanges=false;
	static Color[] defaultColors=new Color[] {Color.red,Color.orange,Color.yellow,Color.green,Color.blue,Color.cyan,Color.magenta};
	Hashtable ballColors=new Hashtable();
	

	abstract class Change {
		int number;
		
		Change(int number) {
			this.number=number;
		}
		protected abstract void undo();
		protected abstract void redo();
	}
	class AddPassChange extends Change {
		EndPoint passPoint;
		EndPoint catchPoint;
		AddPassChange(int number,EndPoint passPoint,EndPoint catchPoint) {
			super(number);
			this.passPoint=passPoint;
			this.catchPoint=catchPoint;
		}
		protected void undo() {
			passPoint.removePass();
		}
		protected void redo() {
			passPoint.makePass(catchPoint);
		}
	}
	class RemovePassChange extends Change {
		EndPoint passPoint;
		EndPoint catchPoint;
		Pass pass;
		RemovePassChange(int number,EndPoint passPoint,EndPoint catchPoint) {
			super(number);
			this.passPoint=passPoint;
			this.catchPoint=catchPoint;
		}
		protected void undo() {
			passPoint.makePass(catchPoint);
		}
		protected void redo() {
			passPoint.removePass();
		}
	}
	
	public PatternController(Pattern pattern) {
		this.pattern=pattern;
	}
	public Pattern getPattern() {
		return pattern;
	}
	public Color getBallColor(Ball ball) {
		Integer number=new Integer(ball.getNumber());
		if (!ballColors.containsKey(number)) {
			return defaultColors[number.intValue()%defaultColors.length];
		}
		return (Color)ballColors.get(number);
	}
	public void setBallColor(Ball ball,Color color) {
		Integer number=new Integer(ball.getNumber());
		if (color==null) {
			ballColors.remove(ball);
		} else {
			if (!getBallColor(ball).equals(color)) {
				ballColors.put(number,color);
				setChanged();
				notifyObservers();
			}
		}
	}
	public void setFilename(String filename) {
		if (filename!=null) this.filename=filename;
	}
	public String getFilename() {
		if (filename==null) {
			untitledCount++;
			filename="untitled"+untitledCount;
		}
		return filename;
	}
	public File getFile() {
		return patternFile;
	}
	protected void setFile(File file) {
		this.patternFile=file;
		this.filename=file.getName();
		// reset undo redo
		undoStack.removeAllElements();
		redoStack.removeAllElements();
		changeCount=0;
	}
	public void openPattern(File file) throws IOException {
		Pattern pattern=fileFormat.readInputStream(new FileInputStream(file));
		this.pattern=pattern;
		setFile(file);
		setChanged();
		notifyObservers();
	}
	public void savePattern(File file) throws IOException {
		fileFormat.writeOutputStream(new FileOutputStream(file),pattern);
		setFile(file);
	}
	public void savePattern() throws IOException {
		savePattern(patternFile);
	}
	/*
	public void setClipboardData(PassCollection passes) {
		if (!passes.equals(clipboardPasses)) {
			clipboardPasses=passes;
			setChanged(); // the clipboard has changed
			notifyObservers();
		}
	}
	public PassCollection getClipboardData() {
		return clipboardPasses;
	}
	*/
	public boolean isModified() {
		return (changeCount>0);
	}
	protected void startMultipleChanges() {
		getNextChangeCount();
		multipleChanges=true;
	}
	protected void finishMultipleChanges() {
		multipleChanges=false;
		notifyObservers();
	}
	protected synchronized int getNextChangeCount() {
		if (!multipleChanges) changeCount++;
		return changeCount;
	}
	public boolean canUndo() {
		return !undoStack.isEmpty();
	}
	public boolean canRedo() {
		return !redoStack.isEmpty();
	}
	public void undo() {
		Change change=(Change)undoStack.pop();
		int n=change.number;
		change.undo();
		redoStack.push(change);
		while (!undoStack.isEmpty() && ((Change)undoStack.peek()).number==n) {
			change=(Change)undoStack.pop();
			change.undo();
			redoStack.push(change);
		}
		changeCount=n-1;
		setChanged();
		notifyObservers();
	}
	public void redo() {
		Change change=(Change)redoStack.pop();
		int n=change.number;
		change.redo();
		undoStack.push(change);
		while (!redoStack.isEmpty() && ((Change)redoStack.peek()).number==n) {
			change=(Change)redoStack.pop();
			change.redo();
			undoStack.push(change);
		}
		changeCount=n;
		setChanged();
		notifyObservers();
	}
	protected void registerChange(Change change) {
		if (!redoStack.isEmpty()) redoStack.clear();
		undoStack.push(change);
		setChanged();
	}
	public boolean removePass(EndPoint endPoint) {
		EndPoint catchPoint=endPoint.getPassDestination();
		if (catchPoint.isValid()) {
			if (endPoint.removePass()) {
				registerChange(new RemovePassChange(getNextChangeCount(),endPoint,catchPoint));
				if (!multipleChanges) notifyObservers();
				return true;
			}
		}
		return false;
	}
	public boolean removePass(int time,int j) {
		Juggler juggler=pattern.getJuggler(j);
		if (juggler.getRightHand().isBeat(time)) removePass(juggler.getRightHand().getEndPoint(time));
		if (juggler.getLeftHand().isBeat(time)) removePass(juggler.getLeftHand().getEndPoint(time));
		return true;
	}
	public boolean addPass(EndPoint from,EndPoint to) {
		if (from.makePass(to)) {
			registerChange(new AddPassChange(getNextChangeCount(),from,to));
			if (!multipleChanges) notifyObservers();
			return true;
		}
		return false;
	}
	public void addJuggler() {
		Juggler juggler=pattern.addJuggler();
		try {
			juggler.getRightHand().setBallCount(2);
			juggler.getLeftHand().setBallCount(1);
		} catch (PatternException e) {}
		setChanged();
		notifyObservers();
	}
	public boolean removeJuggler(int n) {
		Juggler juggler=pattern.getJuggler(n);
		if (juggler!=null) {
			pattern.removeJuggler(juggler);
			setChanged();
			notifyObservers();
			return true;
		}
		return false;
	}
	// todo remove this method when no longer used
	public void patternChanged() {
		setChanged();
		notifyObservers();
	}
}
