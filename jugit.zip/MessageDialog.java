import java.awt.*;
import java.awt.event.*;

class MessageDialog extends Dialog {

	public static int OK=1;
	public static int YES=2;
	public static int NO=4;
	public static int CANCEL=8;

	int result;

	public static int showMessageDialog(Frame parent,String title,String message,int buttons) {
		MessageDialog dialog=new MessageDialog(parent,title,message,buttons);
		dialog.setVisible(true);
		int result=dialog.result;
		dialog.dispose();
		return result;
	}
	public static int showMessageDialog(Dialog parent,String title,String message,int buttons) {
		MessageDialog dialog=new MessageDialog(parent,title,message,buttons);
		dialog.setVisible(true);
		int result=dialog.result;
		dialog.dispose();
		return result;
	}
	MessageDialog(Frame parent,String title,String message,int buttons) {
		super(parent,title,true);
		init(message,buttons);
	}
	MessageDialog(Dialog parent,String title,String message,int buttons) {
		super(parent,title,true);
		init(message,buttons);
	}
	private void init(String message,int buttons) {
		setBackground(Color.white);
		setLayout(new GridBagLayout());
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				result=CANCEL;
				setVisible(false);
			}
		});

		GridBagConstraints gridBagConstraints;
		gridBagConstraints=new GridBagConstraints();
		// add buttons
		Button button;
		int buttonCount=0;
		Insets insets=new Insets(5,5,5,5);
		
		if ((buttons & OK)>0) {
			button=new Button("OK");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					result=OK;
					setVisible(false);
				}
			});
			gridBagConstraints.gridx=buttonCount; buttonCount++;
			gridBagConstraints.gridy=1;
			gridBagConstraints.insets=insets;
			add(button,gridBagConstraints);
		}
		if ((buttons & YES)>0) {
			button=new Button("Yes");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					result=YES;
					setVisible(false);
				}
			});
			gridBagConstraints.gridx=buttonCount; buttonCount++;
			gridBagConstraints.gridy=1;
			gridBagConstraints.insets=insets;
			add(button,gridBagConstraints);
		}
		if ((buttons & NO)>0) {
			button=new Button("No");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					result=NO;
					setVisible(false);
				}
			});
			gridBagConstraints.gridx=buttonCount; buttonCount++;
			gridBagConstraints.gridy=1;
			gridBagConstraints.insets=insets;
			add(button,gridBagConstraints);
		}
		if ((buttons & CANCEL)>0) {
			button=new Button("Cancel");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					result=CANCEL;
					setVisible(false);
				}
			});
			gridBagConstraints.gridx=buttonCount; buttonCount++;
			gridBagConstraints.gridy=1;
			gridBagConstraints.insets=insets;
			add(button,gridBagConstraints);
		}
		Label labelMessage=new Label(message);
		gridBagConstraints.gridx=0;
		gridBagConstraints.gridy=0;
		gridBagConstraints.gridwidth=buttonCount;
		gridBagConstraints.insets=insets;
		add(labelMessage,gridBagConstraints);
		pack();
		// centre the dialog on parent
		if (getParent()!=null) {
			Dimension parentSize=getParent().getSize();
			Dimension size=getSize();
			Point location=getParent().getLocation();
			location.translate(parentSize.width/2-size.width/2,parentSize.height/2-size.height/2);
			setLocation(location);
		}
	}
}
