package juggling;

import java.io.*;
import java.util.*;

public class Juggler {
	Pattern pattern;
	int number;
	Hand leftHand;
	Hand rightHand;

	Juggler(int number,Pattern pattern) {
		this.number=number;
		this.pattern=pattern;
		rightHand=new Hand(number*2,this,new Rhythm("x_"));
		leftHand=new Hand(number*2+1,this,new Rhythm("_x"));
	}
	protected void setNumber(int number) {
		this.number=number;
		rightHand.setNumber(number*2);
		leftHand.setNumber(number*2+1);
	}
	public int getNumber() {
		return number;
	}
	public String getLabel() {
		return new StringBuffer("").append((char)('A'+number)).toString();
	}
	public int getBallCount() {
		return rightHand.getBallCount()+leftHand.getBallCount();
	}
	public Pass getPass(int time) {
		if (rightHand.isBeat(time)) {
			return rightHand.getEndPoint(time).getPass();
		}
		if (leftHand.isBeat(time)) {
			return leftHand.getEndPoint(time).getPass();
		}
		return Pass.NO_PASS;
	}
	public boolean removePass(int time) {
		if (rightHand.isBeat(time)) {
			return rightHand.getEndPoint(time).removePass();
		}
		if (leftHand.isBeat(time)) {
			return leftHand.getEndPoint(time).removePass();
		}
		return false;
	}
	protected void goodbye() {
		rightHand.goodbye();
		leftHand.goodbye();
	}
	public Pattern getPattern() {
		return pattern;
	}
	public Hand getLeftHand() {
		return leftHand;
	}
	public Hand getRightHand() {
		return rightHand;
	}
}
