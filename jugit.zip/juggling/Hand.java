package juggling;

import java.util.*;
import java.io.*;

public class Hand {

	Juggler juggler;
	Rhythm rhythm;
	int ballCount=0;
	int number;
	EndPoint[] endPoints=new EndPoint[ENDPOINT_ARRAY_SIZE];
	static int ENDPOINT_ARRAY_SIZE=20;
	static int ENDPOINT_ARRAY_INCREMENT=20;
	int lastBeat=-1; // the last catch beat

	Hand(int number,Juggler juggler,Rhythm rhythm) {
		this.number=number;
		this.juggler=juggler;
		this.rhythm=rhythm;
	}
	protected void findLastBeat() {
		// find the new last beat
		lastBeat=-1;
		for (int i=0;i<endPoints.length;i++) {
			if (endPoints[i]!=null && endPoints[i].beatIndex>lastBeat && endPoints[i].getCatchOrigin().isValid()) {
				lastBeat=endPoints[i].beatIndex;
			}
		}
	}
	protected int getLastCatchTime() {
		if (lastBeat==-1) return 0;
		return rhythm.getTime(lastBeat+1);
	}
	public void setBallCount(int count) throws PatternException {
		int change=0;
		if (count!=getBallCount()) {
			for (int i=0;i<Math.max(count,ballCount);i++) {
				EndPoint endPoint=getEndPointByBeatIndex(i);
				Ball ball=endPoint.getBall();
				if (i>=count) {
					// remove ball
					if (ball.noBall()) {
						ballCount+=change;
						throw new RuntimeException("Cannot remove ball:Hand is empty");
					}
					getJuggler().getPattern().putBall(endPoint.removeBall());
					change--;
				} else if (i>=ballCount) {
					// add ball
					if (!ball.noBall()) {
						ballCount+=change;
						throw new PatternException("Cannot add ball:Hand already holding a ball");
					}
					endPoint.setBall(getJuggler().getPattern().getBall());
					change++;
				}
			}
			ballCount+=change;
		}
	}
	public int getBallCount() {
		return ballCount;
	}
	public String getLabel() {
		if (isLeft()) return "L";
		return "R";
	}
	public int getNumber() {
		return number;
	}
	protected void setNumber(int number) {
		this.number=number;
	}
	public Juggler getJuggler() {
		return juggler;
	}
	public boolean isLeft() {
		return juggler.getLeftHand().equals(this);
	}
	public boolean isRight() {
		return juggler.getRightHand().equals(this);
	}
	public synchronized void setRhythm(Rhythm rhythm) throws PatternException {
		Rhythm oldRhythm=this.rhythm;
		this.rhythm=rhythm;
		if (!checkPassesAndCatches()) {
			this.rhythm=oldRhythm;
			throw new PatternException("Rhythm is not valid:Cannot catch before pass is made");
		}
	}
	protected boolean checkPassesAndCatches() {
		Iterator it=Arrays.asList(endPoints).iterator();
		while (it.hasNext()) {
			EndPoint endPoint=(EndPoint)it.next();
			if (endPoint!=null) {
				EndPoint passPoint=endPoint.getCatchOrigin();
				if (passPoint.isValid() && passPoint.getTime()>=endPoint.getTime()) return false;
				EndPoint catchPoint=endPoint.getPassDestination();
				if (catchPoint.isValid() && catchPoint.getTime()<=endPoint.getTime()) return false;
			}
		}
		return true;
	}
	public Rhythm getRhythm() {
		return rhythm;
	}
	public Hand getOther() {
		if (isRight()) return juggler.getLeftHand();
		return juggler.getRightHand();
	}
	public boolean isBeat(int time) {
		return rhythm.isBeat(time);
	}
	protected EndPoint getEndPointByBeatIndex(int index) {
		if (index>=endPoints.length) {
			// increase array size
			int newSize=endPoints.length;
			do {
				newSize+=ENDPOINT_ARRAY_INCREMENT;
			} while (index>=newSize);
			EndPoint[] newArray=new EndPoint[newSize];
			System.arraycopy(endPoints,0,newArray,0,endPoints.length);
			endPoints=newArray;
		}
		EndPoint endPoint=endPoints[index];
		if (endPoint==null) endPoints[index]=new EndPoint(this,index);
		return endPoints[index];
	}
	public EndPoint getEndPoint(int time) {
		if (!isBeat(time)) return EndPoint.INVALID_ENDPOINT;
		int index=rhythm.getBeatCount(time)-1;
		return getEndPointByBeatIndex(index);
	}
	// no more passes and catches and balls returned
	protected void goodbye() {
		Iterator it=Arrays.asList(endPoints).iterator();
		while (it.hasNext()) {
			EndPoint endPoint=(EndPoint)it.next();
			if (endPoint!=null) {
				endPoint.removePass();
				EndPoint passPoint=endPoint.getCatchOrigin();
				if (passPoint.isValid()) passPoint.removePass();
			}
		}
		try {
			setBallCount(0);
		} catch (PatternException e) {}
	}
	protected int getTime(EndPoint endPoint) {
		return rhythm.getTime(endPoint.beatIndex+1);
	}
	public boolean makePass(int time,int beats,Hand toHand) {
		EndPoint toEndPoint=toHand.getEndPoint(time+beats);
		EndPoint fromEndPoint=getEndPoint(time);
		return fromEndPoint.makePass(toEndPoint);
	}
}
