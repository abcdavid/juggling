package juggling;

import java.io.*;

public class EndPoint {
	private Hand hand;
	int beatIndex;
	private Ball ball=Ball.NO_BALL;
	private EndPoint catchOrigin=INVALID_ENDPOINT;
	private EndPoint passDestination=INVALID_ENDPOINT;

	public static EndPoint INVALID_ENDPOINT=new EndPoint(null,-1);

	EndPoint(Hand hand,int beatIndex) {
		this.hand=hand;
		this.beatIndex=beatIndex;
	}
	// return the time of this beat
	public int getTime() {
		if (!isValid()) return -1;
		return hand.getTime(this);
	}
	public Hand getHand() {
		return hand;
	}
	public Juggler getJuggler() {
		if (hand==null) return null;
		return hand.getJuggler();
	}
	public Ball getBall() {
		return ball;
	}
	protected void setBall(Ball ball) {
		if (!this.ball.equals(ball)) {
			this.ball=ball;
			if (passDestination.isValid()) {
				passDestination.setBall(ball);
			}
		}
	}
	protected Ball removeBall() {
		Ball aBall=getBall();
		setBall(Ball.NO_BALL);
		return aBall;
	}
	public boolean isValid() {
		return (beatIndex!=-1);
	}
	public boolean equals(Object o) {
		if (o instanceof EndPoint) {
			EndPoint endPoint=(EndPoint)o;
			return (endPoint.beatIndex==beatIndex && ((hand!=null && endPoint.hand!=null && endPoint.hand.equals(hand)) || hand==null && endPoint.hand==null));
		}		
		return false;
	}
	protected Pass getPass() {
		if (isValid() && passDestination.isValid()) {
			int beats=passDestination.getTime()-getTime();
			// is this a switched pass?
			boolean switched=(
					(beats%2==0 && getHand().isLeft()!=passDestination.getHand().isLeft())
					||
					(beats%2==1 && getHand().isLeft()==passDestination.getHand().isLeft())
					);
			if (passDestination.getJuggler().equals(getJuggler())) return new Pass(beats,switched);
			return new Pass(passDestination.getJuggler().getNumber(),beats,switched);
		}
		return Pass.NO_PASS;
	}
	public String getPassLabel() {
		if (!passDestination.isValid()) return "0";
		int beats=passDestination.getTime()-getTime();
		boolean switched=(
					(beats%2==0 && getHand().isLeft()!=passDestination.getHand().isLeft())
					||
					(beats%2==1 && getHand().isLeft()==passDestination.getHand().isLeft())
					);
		boolean passed=!passDestination.getJuggler().equals(getJuggler());
		String label=Integer.toString(beats);
		if (passed) label+='p';
		if (switched) label+='x';
		return label;
	}
	public EndPoint getPassDestination() {
		return passDestination;
	}
	public EndPoint getCatchOrigin() {
		return catchOrigin;
	}
	public EndPoint getNext() {
		return hand.getEndPointByBeatIndex(beatIndex+1);
		
	}
	public boolean makePass(EndPoint endPoint) {
		if (isValid() && endPoint.isValid() && !passDestination.isValid() && !endPoint.catchOrigin.isValid() && endPoint.getBall().noBall() && endPoint.getTime()>getTime()) {
			passDestination=endPoint;
			endPoint.catchOrigin=this;
			endPoint.setBall(ball);
			// keep track of last catch
			if (endPoint.hand.lastBeat<endPoint.beatIndex) endPoint.hand.lastBeat=endPoint.beatIndex;
			return true;
		}
		return false;
	}
	public boolean removePass() {
		if (passDestination.isValid()) {
			passDestination.setBall(Ball.NO_BALL);
			passDestination.catchOrigin=EndPoint.INVALID_ENDPOINT;
			EndPoint endPoint=passDestination;
			passDestination=INVALID_ENDPOINT;
			// keep track of last catch
			if (endPoint.hand.lastBeat==endPoint.beatIndex) endPoint.hand.findLastBeat();
			return true;
		}
		return false;
	}
	public EndPoint[] getPossibleDestinations(Pass pass) {
		int t=getTime()+pass.getBeats();
		if (pass.isSelf()) {
			if (pass.isRtoRorLtoL()) {
				if (getHand().isBeat(t)) return new EndPoint[] {getHand().getEndPoint(t)};
			} else {
				if (getHand().getOther().isBeat(t)) return new EndPoint[] {getHand().getOther().getEndPoint(t)};
			}
			return new EndPoint[] {}; // no valid endpoint found
		}
		java.util.Vector passEndPoints=new java.util.Vector();
		int jugglerCount=getHand().getJuggler().getPattern().getJugglerCount();
		for (int j=0;j<jugglerCount;j++) {
			Juggler juggler=getHand().getJuggler().getPattern().getJuggler(j);
			if (juggler.getNumber()!=getHand().getJuggler().getNumber()) {
				Hand hand;
				if ( (getHand().isRight() && pass.isRtoRorLtoL()) || (getHand().isLeft() && pass.isRtoLorLtoR()) ) hand=juggler.getRightHand();
				else hand=juggler.getLeftHand();
				if (hand.isBeat(t)) passEndPoints.addElement(hand.getEndPoint(t));
			}
		}
		EndPoint[] endPointArray=new EndPoint[passEndPoints.size()];
		passEndPoints.copyInto(endPointArray);
		return endPointArray;
	}
	public String toString() {
		return "EndPoint{time="+getTime()+",hand="+getHand().getNumber()+",ball="+getBall().getNumber()+"}";
	}
}
