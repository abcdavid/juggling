package juggling;

public class PatternException extends Exception {
	PatternException(String message) {
		super(message);
	}
}
