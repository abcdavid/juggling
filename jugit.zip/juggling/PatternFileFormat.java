package juggling;

import java.io.*;

public class PatternFileFormat implements FileFormat {
	public Pattern readInputStream(InputStream input) throws IOException {
		return PatternParser.readPattern(input);
	}
	public void writeOutputStream(OutputStream output,Pattern pattern) throws IOException {
		BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(output));
		String nl=System.getProperty("line.separator");
		int jCount=pattern.getJugglerCount();
		writer.write("jugglers {"+jCount+"}// number of jugglers"+nl);
		writer.write("hands ");
		for (int j=0;j<jCount;j++) {
			Juggler juggler=pattern.getJuggler(j);
			writer.write("{"+juggler.getRightHand().getRhythm().toString()+"}// right hand rhythm"+nl);
			writer.write("{"+juggler.getLeftHand().getRhythm().toString()+"}// left hand rhythm"+nl);
		}
		writer.write("balls {");
		for (int i=0;i<jCount;i++) {
			writer.write(" "+Integer.toString(pattern.getJuggler(i).getRightHand().getBallCount())+" "+Integer.toString(pattern.getJuggler(i).getLeftHand().getBallCount()));
		}
		writer.write(" }"+nl);
		writer.write("passes ");
		for (int h=0;h<pattern.getHandCount();h++) {
			writer.write("{ ");
			Hand hand=pattern.getHand(h);
			int time=0;
			while (time<pattern.getTotalTime()) {
				if (hand.isBeat(time)) {
					EndPoint passPoint=hand.getEndPoint(time);
					EndPoint catchPoint=passPoint.getPassDestination();
					String passStr;
					if (!catchPoint.isValid()) {
						passStr="0";
					} else {
						int beats=catchPoint.getTime()-passPoint.getTime();
						passStr=Integer.toString(beats)+","+Integer.toString(catchPoint.getHand().getNumber());
					}
					writer.write(passStr+" ");
				}
				time++;
			}
			writer.write("}"+nl);
		}
		writer.flush();
		writer.close();
	}
}
