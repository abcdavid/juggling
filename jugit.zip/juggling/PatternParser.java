// $ANTLR 2.7.1: "juggling/pattern.g" -> "PatternParser.java"$
package juggling;

import java.io.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class PatternParser extends antlr.LLkParser
       implements PatternParserTokenTypes
 {

	public static Pattern readPattern(InputStream input) throws IOException {
		try {
			PatternLexer lexer = new PatternLexer(new InputStreamReader(input));
			TokenBuffer buffer = new TokenBuffer(lexer);
			PatternParser parser = new PatternParser(buffer);
			return parser.pattern();
		} catch(Exception e) {
			throw new IOException(e.getMessage());
		}
	}
	private int getNextBeat(int time,Hand hand) {
		while (!hand.isBeat(time)) time++;
		return time;
	}
	

protected PatternParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public PatternParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected PatternParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public PatternParser(TokenStream lexer) {
  this(lexer,1);
}

public PatternParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final Pattern  pattern() throws RecognitionException, TokenStreamException {
		Pattern pattern;
		
		Token  n = null;
		Token  r = null;
		Token  bc = null;
		Token  b = null;
		Token  h = null;
		
			pattern=new Pattern();
			int hand=0;
			int time;
		
		
		try {      // for error handling
			match(JUGGLERS);
			match(LC);
			n = LT(1);
			match(NUMBER);
			match(RC);
			/*System.out.println("jugglers:"+n.getText());*/ pattern.setJugglerCount(Integer.valueOf(n.getText()).intValue());
			match(HANDS);
			{
			int _cnt3=0;
			_loop3:
			do {
				if ((LA(1)==LC)) {
					match(LC);
					r = LT(1);
					match(RHYTHM);
					match(RC);
					
								//System.out.println("hands:"+r.getText());
								try {
									pattern.getHand(hand).setRhythm(Rhythm.getRhythm(r.getText()));
									hand++;
								} catch (PatternException e) {
									System.err.println(e.getMessage());
									e.printStackTrace(System.err);
								}
							
				}
				else {
					if ( _cnt3>=1 ) { break _loop3; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt3++;
			} while (true);
			}
			match(BALLS);
			
				hand=0;
			
			match(LC);
			{
			int _cnt5=0;
			_loop5:
			do {
				if ((LA(1)==NUMBER)) {
					bc = LT(1);
					match(NUMBER);
					
								//System.out.println("balls:"+bc.getText());
								try {
									pattern.getHand(hand).setBallCount(Integer.valueOf(bc.getText()).intValue());
									hand++;
								} catch (PatternException e) {
									System.err.println(e.getMessage());
									e.printStackTrace(System.err);
								}
							
				}
				else {
					if ( _cnt5>=1 ) { break _loop5; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt5++;
			} while (true);
			}
			match(RC);
			match(PASSES);
			
				hand=0;
			
			{
			int _cnt11=0;
			_loop11:
			do {
				if ((LA(1)==LC)) {
					match(LC);
					time=getNextBeat(0,pattern.getHand(hand));
					{
					_loop10:
					do {
						if ((LA(1)==NUMBER)) {
							b = LT(1);
							match(NUMBER);
							{
							if (((LA(1)==COMMA))&&(!b.getText().equals("0"))) {
								{
								match(COMMA);
								h = LT(1);
								match(NUMBER);
								
															//System.out.println("passes:"+b.getText()+","+h.getText());
															int beats=Integer.valueOf(b.getText()).intValue();
															int toHand=Integer.valueOf(h.getText()).intValue();
															if (!pattern.getHand(hand).makePass(time,beats,pattern.getHand(toHand))) System.err.println("Failed to make pass: time="+time+",beats="+beats+",fromHand="+hand+",toHand="+toHand);
														
								}
							}
							else if ((LA(1)==NUMBER||LA(1)==RC)) {
							}
							else {
								throw new NoViableAltException(LT(1), getFilename());
							}
							
							}
							time=getNextBeat(time+1,pattern.getHand(hand));
						}
						else {
							break _loop10;
						}
						
					} while (true);
					}
					match(RC);
					hand++;
				}
				else {
					if ( _cnt11>=1 ) { break _loop11; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt11++;
			} while (true);
			}
			match(Token.EOF_TYPE);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_0);
		}
		return pattern;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"JUGGLERS",
		"LC",
		"NUMBER",
		"RC",
		"HANDS",
		"RHYTHM",
		"BALLS",
		"PASSES",
		"COMMA",
		"SL_COMMENT",
		"ML_COMMENT",
		"WS"
	};
	
	private static final long _tokenSet_0_data_[] = { 2L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	
	}
