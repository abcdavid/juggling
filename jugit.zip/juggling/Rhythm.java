package juggling;

public class Rhythm {

	boolean[] beats;
	int struck=0;

	Rhythm(String text) {
		beats=new boolean[text.length()];
		text=text.toLowerCase();
		for (int i=0;i<text.length();i++) {
			beats[i]=(text.charAt(i)=='x');
			if (beats[i]) {
				struck++;
			}
			
		}
		if (struck==0) throw new IllegalArgumentException("Invalid rhythm:"+text);
	}
	public static Rhythm getRhythm(String text) throws IllegalArgumentException {
		return new Rhythm(text);
	}
	public String toString() {
		StringBuffer buf=new StringBuffer();
		buf.setLength(beats.length);
		for (int i=0;i<beats.length;i++) {
			buf.setCharAt(i,beats[i]?'x':'_');
		}
		return buf.toString();
	}
	public boolean isBeat(int beat) {
		return beats[beat%beats.length];
	}
// how many beats up to and including this time
	public int getBeatCount(int time) {
		// calculate complete cycles
		int cycleNo=time/beats.length;
		int count=cycleNo*struck;
		int extra=time%beats.length+1; // +1 to allow beat at zero time
		for (int i=0;i<extra;i++) {
			if (beats[i]) count++;
		}
		return count;
	}
	public int getTime(int beatCount) {
		int cycles=(beatCount-1)/getBeatsPerRepeat(); // don't miss the last beat
		int time=cycles*getRepeatLength()-1;
		int count=cycles*getBeatsPerRepeat();
		// now find the last beat
		while (count<beatCount) {
			time++;
			if (isBeat(time)) count++;
		}
		return time;
	}
	public int getRepeatLength() {
		return beats.length;
	}
	public int getBeatsPerRepeat() {
		return struck;
	}
}
