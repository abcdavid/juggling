import java.applet.*;
import java.awt.*;

public class LaunchApplet extends Applet {

	public void init() {
		JugglingApp.main(new String[] {"441"});
	}
}
