import java.awt.*;
import java.util.*;

import animation.*;
import juggling.*;

public abstract class JugglingAnimation extends AnimationCanvas {
	PatternController patternController;
	private long beatTime;  // how many milliseconds per beat
	private long handTime; // how many milliseconds between catching and throwing
	private int ballRadius;
	private boolean initDone=false;
	private Observer patternObserver=new Observer() {
		public void update(Observable ob,Object o) {
			setBeatTime(beatTime); // indirectly calls setTotalTime if length of animation has changed
			initAnimation(); // reinitialises
			repaint(); // updates ball colours
		}
	};

	public JugglingAnimation(PatternController patternController) {
		this.patternController=patternController;
		// todo be nice - remove observer aswell
		patternController.addObserver(patternObserver);
		setBeatTime(500);
		handTime=400;
		ballRadius=10;
	}
	public long getBeatTime() {
		return beatTime;
	}
	public void setBeatTime(long millis) {
		this.beatTime=millis;
		setTotalTime((long)patternController.getPattern().getTotalTime()*beatTime);
	}
	public long getHandTime(int throwBeats) {
		if (throwBeats==1) return handTime/2;
		return handTime;
	}
	public void setHandTime(long millis) {
		if (millis>beatTime) throw new RuntimeException("handTime>beatTime");
		this.handTime=millis;
	}
	public int getBallRadius() {
		return ballRadius;
	}
	public void setBallRadius(int r) {
		ballRadius=r;
	}
	public void start() {
		synchronized (this) {
			if (!initDone) {
				initAnimation();
				initDone=true;
			}
		}
		super.start();
	}
	// override this method for any required initialisation
	public void initAnimation() {}
	public abstract void render(Graphics g,long time);
	
	protected void drawBall(Graphics g,int x,int y,Ball ball) {
		g.setColor(patternController.getBallColor(ball));
		g.fillOval(x-ballRadius,y-ballRadius,ballRadius*2,ballRadius*2);
	}
	protected void drawHand(Graphics g,Point p) {
		g.setColor(Color.black);
		g.drawLine(p.x-2,p.y,p.x+2,p.y);
		g.drawLine(p.x,p.y-2,p.x,p.y+2);
	}
}
