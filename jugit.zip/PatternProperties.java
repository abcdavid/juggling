import juggling.*;

import java.awt.*;
import java.awt.event.*;
import java.util.Observer;
import java.util.Observable;

public class PatternProperties extends java.awt.Dialog {
    
    PatternController patternController;
    KeyListener keyListener=new KeyAdapter() {
	    public void keyTyped(KeyEvent e) {
		    if (e.getKeyChar()==e.VK_BACK_SPACE || e.getKeyChar()==e.VK_DELETE || e.getKeyChar()==e.VK_ENTER) {
			    // do nothing
		    } else if (e.getKeyChar()==e.VK_SPACE || e.getKeyChar()=='_' || e.getKeyChar()=='-') {
			    e.setKeyChar('_');
		    } else {
			    e.setKeyChar('x');
		    }
	    }
    };

    public PatternProperties(java.awt.Frame parent, PatternController patternController) {
        super(parent, true);
	this.patternController=patternController;
        initComponents();
	if (parent!=null) {
		Point location=parent.getLocation();
		Dimension parentSize=parent.getSize();
		Dimension size=getSize();
		location.translate(parentSize.width/2-size.width/2,parentSize.height/2-size.height/2);
		setLocation(location);
	}
	patternController.addObserver(new Observer() {
		public void update(Observable ob,Object o) {
			patternUpdate(((PatternController)ob).getPattern());
		}
	});
	patternUpdate(patternController.getPattern());
    }
    private void patternUpdate(Pattern pattern) {
	    // initialize components according to pattern
	    for (int j=0;j<pattern.getJugglerCount();j++) {
		    String label=pattern.getJuggler(j).getLabel();
		    if (!(listJugglers.getItemCount()>j && listJugglers.getItem(j).equals(label))) listJugglers.add(pattern.getJuggler(j).getLabel());
	    }
	    while (listJugglers.getItemCount()>pattern.getJugglerCount()) listJugglers.remove(pattern.getJugglerCount());
	    if (pattern.getJugglerCount()>0 && listJugglers.getSelectedIndex()<0) {
		    listJugglers.select(0);
	    }
	    selectionUpdate();
    }
    private void selectionUpdate() {
	    boolean selected=(listJugglers.getSelectedIndex()>=0);
	    btnRemoveJuggler.setEnabled(selected);
	    if (selected) jugglerProperties.updateJuggler(patternController.getPattern().getJuggler(listJugglers.getSelectedIndex()));
	    else jugglerProperties.updateJuggler(null);
    }
    
    private void initComponents() {
	setBackground(Color.white);
        java.awt.GridBagConstraints gridBagConstraints;

        lblJugglers = new java.awt.Label();
        listJugglers = new java.awt.List();
        btnAddJuggler = new java.awt.Button();
        btnRemoveJuggler = new java.awt.Button();
	jugglerProperties=new JugglerProperties();
        panelButtons = new java.awt.Panel();
        btnOK = new java.awt.Button();
	
	listJugglers.setMultipleMode(false);
	// event handlers
	listJugglers.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent e) {
			selectionUpdate();
		}
	});
	btnAddJuggler.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			doAddJuggler();
		}
	});
	btnRemoveJuggler.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			doRemoveJuggler();
		}
	});
	btnOK.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			closeDialog(e);
		}
	});
	
        setLayout(new java.awt.GridBagLayout());

        setModal(true);
        setResizable(false);
        setTitle("Pattern Properties");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        lblJugglers.setText("Jugglers");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        add(lblJugglers, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridheight = 3;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(listJugglers, gridBagConstraints);

        btnAddJuggler.setLabel("Add");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        add(btnAddJuggler, gridBagConstraints);

        btnRemoveJuggler.setLabel("Remove");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        add(btnRemoveJuggler, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jugglerProperties, gridBagConstraints);

        btnOK.setLabel("OK");
        panelButtons.add(btnOK);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 2;
        add(panelButtons, gridBagConstraints);

        pack();
    }
    
    private void doAddJuggler() {
	    patternController.addJuggler();
    }
    private void doRemoveJuggler() {
	    int index=listJugglers.getSelectedIndex();
	    patternController.removeJuggler(index);
    }
    private void closeDialog(java.awt.AWTEvent evt) {
        setVisible(false);
        dispose();
    }
    
    
    private java.awt.Label lblJugglers;
    private java.awt.Button btnOK;
    private java.awt.Button btnRemoveJuggler;
    private java.awt.Button btnAddJuggler;
    private java.awt.List listJugglers;
    private java.awt.Panel panelButtons;
    private JugglerProperties jugglerProperties;
    
	class JugglerProperties extends java.awt.Panel {
	
		Juggler juggler;
		int maxBalls=9;
	
		JugglerProperties() {
			initComponents();
			setEnabled(false);
		}
		public void updateJuggler(Juggler juggler) {
			this.juggler=juggler;
			if (juggler!=null) {
				setEnabled(true);
				ballNumberRHChoice.select(Integer.toString(juggler.getRightHand().getBallCount()));
				ballNumberLHChoice.select(Integer.toString(juggler.getLeftHand().getBallCount()));
				rhRhythmText.setText(juggler.getRightHand().getRhythm().toString());
				lhRhythmText.setText(juggler.getLeftHand().getRhythm().toString());
			} else {
				setEnabled(false);
			}
		}
		public void setEnabled(boolean isEnabled) {
			ballNumberRHChoice.setEnabled(isEnabled);
			ballNumberLHChoice.setEnabled(isEnabled);
			rhRhythmText.setEnabled(isEnabled);
			lhRhythmText.setEnabled(isEnabled);
			if (!isEnabled) {
				rhRhythmText.setText("");
				lhRhythmText.setText("");
			}
		}
	
		private void initComponents() {
			java.awt.GridBagConstraints gridBagConstraints;
			
			jugglerLabel = new java.awt.Label();
			ballsRHLabel = new java.awt.Label();
			ballsLHLabel = new java.awt.Label();
			ballNumberRHChoice = new java.awt.Choice();
			ballNumberLHChoice = new java.awt.Choice();
			rhRhythmLabel = new java.awt.Label();
			rhRhythmText = new java.awt.TextField();
			lhRhythmLabel = new java.awt.Label();
			lhRhythmText = new java.awt.TextField();
			
			setLayout(new java.awt.GridBagLayout());
			
			for (int i=0;i<maxBalls;i++) {
				String b=Integer.toString(i);
			    ballNumberRHChoice.add(b);
			    ballNumberLHChoice.add(b);
			}
			ballNumberRHChoice.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if (e.getStateChange()==e.SELECTED) {
						try {
							juggler.getRightHand().setBallCount(Integer.valueOf(ballNumberRHChoice.getSelectedItem()).intValue());
							patternController.patternChanged();
						} catch (PatternException ex) {
							MessageDialog.showMessageDialog(PatternProperties.this,"Cannot make change",ex.getMessage(),MessageDialog.OK);
							ballNumberRHChoice.select(juggler.getRightHand().getBallCount());
						}
					}
				}
			});
			ballNumberLHChoice.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if (e.getStateChange()==e.SELECTED) {
						try {
							juggler.getLeftHand().setBallCount(Integer.valueOf(ballNumberLHChoice.getSelectedItem()).intValue());
							patternController.patternChanged();
						} catch (PatternException ex) {
							MessageDialog.showMessageDialog(PatternProperties.this,"Cannot make change",ex.getMessage(),MessageDialog.OK);
							ballNumberLHChoice.select(juggler.getLeftHand().getBallCount());
						}
					}
				}
			});
			rhRhythmText.addKeyListener(keyListener);
			lhRhythmText.addKeyListener(keyListener);
			rhRhythmText.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					//rhRhythmChanged();
					rhRhythmText.transferFocus(); // triggers change
				}
			});
			rhRhythmText.addFocusListener(new FocusAdapter() {
				public void focusLost(FocusEvent e) {
					rhRhythmChanged();
				}
			});
			lhRhythmText.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					lhRhythmText.transferFocus(); // triggers change
					//lhRhythmChanged();
				}
			});
			lhRhythmText.addFocusListener(new FocusAdapter() {
				public void focusLost(FocusEvent e) {
					lhRhythmChanged();
				}
			});
	
			jugglerLabel.setAlignment(java.awt.Label.CENTER);
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.gridwidth = 2;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(jugglerLabel, gridBagConstraints);
			
			ballsRHLabel.setAlignment(java.awt.Label.RIGHT);
			ballsRHLabel.setText("Number of Balls (Right):");
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 1;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(ballsRHLabel, gridBagConstraints);
			
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.gridy = 1;
			add(ballNumberRHChoice, gridBagConstraints);
			
			ballsLHLabel.setAlignment(java.awt.Label.RIGHT);
			ballsLHLabel.setText("Number of Balls (Left):");
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 2;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(ballsLHLabel, gridBagConstraints);
			
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.gridy = 2;
			add(ballNumberLHChoice, gridBagConstraints);
			
			rhRhythmLabel.setAlignment(java.awt.Label.RIGHT);
			rhRhythmLabel.setText("Right Hand Rhythm:");
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 3;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(rhRhythmLabel, gridBagConstraints);
			
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.gridy = 3;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(rhRhythmText, gridBagConstraints);
			
			lhRhythmLabel.setAlignment(java.awt.Label.RIGHT);
			lhRhythmLabel.setText("Left Hand Rhythm:");
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 4;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(lhRhythmLabel, gridBagConstraints);
			
			gridBagConstraints = new java.awt.GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.gridy = 4;
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			add(lhRhythmText, gridBagConstraints);
			
			pack();
		}
	
		private void rhRhythmChanged() {
			try {
				juggler.getRightHand().setRhythm(Rhythm.getRhythm(rhRhythmText.getText()));
				patternController.patternChanged();
			} catch (final Exception e) {
				// thread to avoid paint problem
				Thread thread=new Thread() {
					public void run() {
						MessageDialog.showMessageDialog(PatternProperties.this,"Cannot make change",e.getMessage(),MessageDialog.OK);
					}
				};
				thread.start();
				rhRhythmText.setText(juggler.getRightHand().getRhythm().toString());
			}
		}
		private void lhRhythmChanged() {
			try {
				juggler.getLeftHand().setRhythm(Rhythm.getRhythm(lhRhythmText.getText()));
				patternController.patternChanged();
			} catch (final Exception e) {
				// thread to avoid paint problem
				Thread thread=new Thread() {
					public void run() {
						MessageDialog.showMessageDialog(PatternProperties.this,"Cannot make change",e.getMessage(),MessageDialog.OK);
					}
				};
				thread.start();
				lhRhythmText.setText(juggler.getLeftHand().getRhythm().toString());
			}
		}
	
	    private java.awt.TextField rhRhythmText;
	    private java.awt.TextField lhRhythmText;
	    private java.awt.Choice ballNumberRHChoice;
	    private java.awt.Choice ballNumberLHChoice;
	    private java.awt.Label rhRhythmLabel;
	    private java.awt.Label lhRhythmLabel;
	    private java.awt.Label jugglerLabel;
	    private java.awt.Label ballsRHLabel;
	    private java.awt.Label ballsLHLabel;
	    
	}
}
