import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

import juggling.*;

public class JugglingApp extends Frame {

	ScrollPane scrollPane;
	LadderDiagram ladderDiagram;
	PatternController patternController;
	Observer patternObserver=new Observer() {
		public void update(Observable ob,Object o) {
			patternUpdate((PatternController)ob);
		}
	};
	Hashtable controllers=new Hashtable();

	MenuBar menuBar=new MenuBar();
	
	Menu menuFile=new Menu("File");
	MenuItem menuNewPattern=new MenuItem("New pattern...");
	MenuItem menuSiteswap=new MenuItem("New siteswap...");
	MenuItem menuOpen=new MenuItem("Open...");
	MenuItem menuSave=new MenuItem("Save");
	MenuItem menuSaveAs=new MenuItem("Save as...");
	MenuItem menuClose=new MenuItem("Close");
	MenuItem menuExit=new MenuItem("Quit");
	
	Menu menuEdit=new Menu("Edit");
	MenuItem menuUndo=new MenuItem("Undo");
	MenuItem menuRedo=new MenuItem("Redo");
	MenuItem menuCut=new MenuItem("Cut");
	MenuItem menuCopy=new MenuItem("Copy");
	MenuItem menuPaste=new MenuItem("Paste");
	MenuItem menuRemove=new MenuItem("Remove");

	Menu menuPattern=new Menu("Pattern");
	String[] toggleLabels=new String[] {"Show causal diagram","Show ladder diagram"};
	MenuItem menuPatternCausal=new MenuItem(toggleLabels[0]);
	MenuItem menuPatternProperties=new MenuItem("Properties...");
	MenuItem menuPatternColors=new MenuItem("Colours...");
	MenuItem menuPatternAnimate=new MenuItem("Animate...");
	
	JugglingApp(Pattern pattern) {
		super("Juggling Explorer");
		PatternController controller=new PatternController(pattern);
		ladderDiagram=new LadderDiagram(/*patternController*/);	
		setLayout(new GridLayout(1,1));
		scrollPane=new ScrollPane();
		scrollPane.add(ladderDiagram);
		add(scrollPane);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				doExit();
			}
		});
		menuBar.add(menuFile);
		menuFile.add(menuNewPattern);
		menuNewPattern.setShortcut(new MenuShortcut(KeyEvent.VK_N));
		menuNewPattern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doNewPattern();
			}
		});
		menuFile.add(menuSiteswap);
		menuSiteswap.setShortcut(new MenuShortcut(KeyEvent.VK_M));
		menuSiteswap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doOpenSiteswap();
			}
		});
		menuFile.add(menuOpen);
		menuOpen.setShortcut(new MenuShortcut(KeyEvent.VK_O));
		menuOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doOpen();
			}
		});
		menuFile.add(menuSave);
		menuSave.setShortcut(new MenuShortcut(KeyEvent.VK_S));
		menuSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doSave();
			}
		});
		menuFile.add(menuSaveAs);
		menuSaveAs.setShortcut(new MenuShortcut(KeyEvent.VK_A));
		menuSaveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doSaveAs();
			}
		});
		menuFile.add(menuClose);
		menuClose.setShortcut(new MenuShortcut(KeyEvent.VK_W));
		menuClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doClose();
			}
		});
		menuFile.add(menuExit);
		menuExit.setShortcut(new MenuShortcut(KeyEvent.VK_Q));
		menuExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doExit();
			}
		});
		menuUndo.setShortcut(new MenuShortcut(KeyEvent.VK_U));
		menuUndo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.undo();
			}
		});
		menuRedo.setShortcut(new MenuShortcut(KeyEvent.VK_R));
		menuRedo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.redo();
			}
		});
		menuCut.setShortcut(new MenuShortcut(KeyEvent.VK_X));
		menuCut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ladderDiagram.getSelectionModel().cut();
			}
		});
		menuCopy.setShortcut(new MenuShortcut(KeyEvent.VK_C));
		menuCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ladderDiagram.getSelectionModel().copy();
			}
		});
		menuPaste.setShortcut(new MenuShortcut(KeyEvent.VK_V));
		menuPaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ladderDiagram.getSelectionModel().paste();
			}
		});
		menuRemove.setShortcut(new MenuShortcut(KeyEvent.VK_D));
		menuRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ladderDiagram.getSelectionModel().remove();
			}
		});
		menuBar.add(menuEdit);
		menuEdit.add(menuUndo);
		menuEdit.add(menuRedo);
		menuEdit.add(menuCut);
		menuEdit.add(menuCopy);
		menuEdit.add(menuPaste);
		menuEdit.add(menuRemove);
		
		menuBar.add(menuPattern);
		menuPattern.add(menuPatternCausal);
		menuPatternCausal.setShortcut(new MenuShortcut(KeyEvent.VK_L));
		menuPatternCausal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MenuItem menuItem=(MenuItem)e.getSource();
				if (ladderDiagram.isCausal()) {
					ladderDiagram.setShowCausal(false);
					menuItem.setLabel(toggleLabels[0]);
				} else {
					ladderDiagram.setShowCausal(true);
					menuItem.setLabel(toggleLabels[1]);
				}
			}
		});
		menuPattern.add(menuPatternProperties);
		menuPatternProperties.setShortcut(new MenuShortcut(KeyEvent.VK_P));
		menuPatternProperties.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showPatternProperties();
			}
		});
		menuPattern.add(menuPatternColors);
		menuPatternColors.setShortcut(new MenuShortcut(KeyEvent.VK_I));
		menuPatternColors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BallColors.showColorsDialog(JugglingApp.this,patternController);
			}
		});
		
		menuPattern.add(menuPatternAnimate);
		menuPatternAnimate.setShortcut(new MenuShortcut(KeyEvent.VK_J));
		menuPatternAnimate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				animate();
			}
		});
		menuPattern.addSeparator();
		addController(controller);
		
		setMenuBar(menuBar);
		ladderDiagram.getSelectionModel().addObserver(new Observer() {
			public void update(Observable ob,Object o) {
				selectionUpdate((LadderDiagram.SelectionModel)ob);
			}
		});
		ladderDiagram.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				Dimension newSize=getPreferredSize();
				if (!getSize().equals(newSize)) {
					setSize(getPreferredSize());
					doLayout();
					validate();
				}
				// scrollPane must always be notified
				scrollPane.doLayout();
				scrollPane.validate();
			}
		});
		setController(controller);
		selectionUpdate(ladderDiagram.getSelectionModel());
		setSize(getPreferredSize());
		setResizable(false);
		setLocation(100,100);
	}
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}
	public Dimension getPreferredSize() {
		// try to size nicely
		Dimension ladderSize=ladderDiagram.getSize();
		Dimension maxSize=Toolkit.getDefaultToolkit().getScreenSize();
		addNotify(); // ensure peer is created to get correct insets
		Insets insets=getInsets();
		return new Dimension(Math.min(ladderSize.width+insets.left+insets.right+4,maxSize.width),Math.min(ladderSize.height+insets.top+insets.bottom+4,maxSize.height));
	}
	public void patternUpdate(PatternController patternController) {
		menuSave.setEnabled(patternController.isModified());
		menuUndo.setEnabled(patternController.canUndo());
		menuRedo.setEnabled(patternController.canRedo());
	}
	public void selectionUpdate(LadderDiagram.SelectionModel selectionModel) {
		boolean selected=selectionModel.isSelected();
		menuCut.setEnabled(selected);
		menuCopy.setEnabled(selected);
		menuPaste.setEnabled(selected);
		menuRemove.setEnabled(selected);
	}
	protected PatternController getController() {
		return patternController;
	}
	protected void setController(PatternController controller) {
		if (patternController!=null) patternController.deleteObserver(patternObserver);
		patternController=controller;
		if (patternController!=null) {
			patternController.addObserver(patternObserver);
			setTitle("Juggling Explorer - "+patternController.getFilename());
		}
		ladderDiagram.setController(controller);
		patternUpdate(patternController);
	}
	class PatternMenuItem extends MenuItem implements ActionListener {
		PatternController controller;
		PatternMenuItem(PatternController controller) {
			this.controller=controller;
			updateLabel();
			addActionListener(PatternMenuItem.this);
		}
		public void actionPerformed(ActionEvent e) {
			setController(controller);
		}
		public void updateLabel() {
			setLabel(controller.getFilename());
		}
	}
	protected void updatePatternName(PatternController controller) {
		PatternMenuItem menuItem=(PatternMenuItem)controllers.get(controller);
		menuItem.updateLabel();
		setTitle("Juggling Explorer - "+controller.getFilename());
	}
	protected MenuShortcut getMenuShortcut(int no) {
		if (no<9)
			return new MenuShortcut(KeyEvent.VK_1+no);
		if (no<18)
			return new MenuShortcut(KeyEvent.VK_1+no-9,true);
		return null;
	}
	protected void addController(PatternController controller) {
		MenuItem patternMenuItem=new PatternMenuItem(controller);
		MenuShortcut menuShortcut=getMenuShortcut(controllers.size());
		if (menuShortcut!=null) patternMenuItem.setShortcut(menuShortcut);
		controllers.put(controller,patternMenuItem);
		menuPattern.add(patternMenuItem);
	}
	private void doNewPattern() {
		Pattern pattern=new Pattern();
		Juggler juggler=pattern.addJuggler();
		try {
			juggler.getRightHand().setBallCount(2);
			juggler.getLeftHand().setBallCount(1);
		} catch (PatternException e) {}
		PatternController controller=new PatternController(pattern);
		addController(controller);
		setController(controller);
		showPatternProperties();
	}
	private void doOpenSiteswap() {
		SiteswapDialog dialog=new SiteswapDialog(JugglingApp.this,true);
		dialog.setVisible(true);
		Pattern pattern=dialog.getPattern();
		if (pattern!=null) {
			PatternController controller=new PatternController(pattern);
			controller.setFilename(dialog.getSiteswap());
			addController(controller);
			setController(controller);
		}
		dialog.dispose();
	}
	private boolean isOpen(File file) {
		Enumeration enum=controllers.keys();
		while (enum.hasMoreElements()) {
			PatternController controller=(PatternController)enum.nextElement();
			if (controller.getFile()!=null && file.equals(controller.getFile())) return true;
		}
		return false;
	}
	private void doOpen() {
		FileDialog fileDialog=new FileDialog(this,"Open",FileDialog.LOAD);
		fileDialog.setVisible(true);
		if (fileDialog.getFile()!=null) {
			try {
				File file=new File(fileDialog.getDirectory(),fileDialog.getFile());
				if (isOpen(file)) {
					MessageDialog.showMessageDialog(this,"Cannot open file","File already open",MessageDialog.OK);
					return;
				}
				PatternController patternController=new PatternController(new Pattern());
				patternController.openPattern(file);
				addController(patternController);
				setController(patternController);
			} catch (IOException e) {
				MessageDialog.showMessageDialog(this,"Error opening file",e.getMessage(),MessageDialog.OK);
				System.err.println(e.getMessage());
			}
		}
	}
	private void doSave() {
		if (patternController.getFile()!=null) {
			try {
				patternController.savePattern();
			} catch (IOException e) {
				MessageDialog.showMessageDialog(this,"Error saving file",e.getMessage(),MessageDialog.OK);
				System.err.println(e.getMessage());
			}
		} else {
			doSaveAs();
		}
	}
	private void doSaveAs() {
		FileDialog fileDialog=new FileDialog(this,"Save",FileDialog.SAVE);
		// following line causes fault!
		//if (patternController.getFilename()!=null) fileDialog.setFile(patternController.getFilename());
		fileDialog.setVisible(true);
		if (fileDialog.getFile()!=null) {
			try {
				File file=new File(fileDialog.getDirectory(),fileDialog.getFile());
				patternController.savePattern(file);
				updatePatternName(patternController); // filename changed in menu
			} catch (IOException e) {
				MessageDialog.showMessageDialog(this,"Error saving file",e.getMessage(),MessageDialog.OK);
			}
		}
	}
	private boolean doClose() {
		if (patternController.isModified()) {
			int result;
			if ((result=MessageDialog.showMessageDialog(this,"Pattern changed","Do you want to save changes?",MessageDialog.YES | MessageDialog.NO | MessageDialog.CANCEL))==MessageDialog.YES) {
				doSave();
			} else if (result==MessageDialog.CANCEL) {
				return false;
			}
		}
		// remove from shortcut
		MenuItem patternShortcut=(MenuItem)controllers.get(patternController);
		menuPattern.remove(patternShortcut);
		controllers.remove(patternController);
		if (!controllers.isEmpty()) {
			setController((PatternController)controllers.keys().nextElement());
		} else {
			// exit if no more patterns
			setVisible(false);
			dispose();
			System.exit(0);
		}
		return true;
	}
	private void doExit() {
		while (getController()!=null) {
			if (!doClose()) return;
		}
	}
	private void animate() {
		Frame frame=new Frame("Pattern Animation");
		frame.setLayout(new GridLayout(1,1));
		JugglingAnimation animation;
		if (patternController.getPattern().getJugglerCount()==1) {
			animation=new SoloJugglerAnimation(patternController);
			animation.setSize(300,500);
		} else {
			animation=new PassingAnimation(patternController);
			animation.setSize(300,300);
		}
		animation.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				JugglingAnimation anim=(JugglingAnimation)e.getSource();
				if (anim.hasFinished()) anim.play();
				else anim.pause();
			}
		});
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				Frame theFrame=(Frame)e.getSource();
				theFrame.setVisible(false);
				theFrame.dispose();
			}
		});
		frame.add(animation);
		frame.setSize(frame.getPreferredSize());
		frame.setVisible(true);
		animation.play();
	}
	private void showPatternProperties() {
		PatternProperties patternProperties=new PatternProperties(this,patternController);
		patternProperties.setVisible(true);
	}
	public static void main(String[] args) {
		try {
			Pattern pattern;
			if (args.length>0) {
				pattern=SiteswapParser.readSiteswap(args[0]);
			} else {
				// simple example
				pattern=SiteswapParser.readSiteswap("333");
			}
			JugglingApp app=new JugglingApp(pattern);
			app.setVisible(true);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
