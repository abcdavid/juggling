import java.awt.*;
import java.awt.event.*;
import java.awt.Image.*;
import java.util.*;

import juggling.*;

public class LadderDiagram extends Canvas {

	static int DEFAULT=0;
	static int PASSING=1;
	static int SELECTING=2;

	int mode=DEFAULT;

	/* Allow selection of :
	a single EndPoint,
	a range of EndPoints of a single Juggler (one or both hands)
	a range of EndPoints for n Jugglers (both hands)
	i.e. cannot select EndPoints which are not adjacent
	*/
	class SelectionModel extends Observable {
		// selection limits TopLeft and BottomRight
		Vector selectedEndPoints=new Vector();

		EndPoint startSelection=EndPoint.INVALID_ENDPOINT;
		EndPoint endSelection=EndPoint.INVALID_ENDPOINT;
		
		Rectangle selectionBounds;
		
		public Rectangle getSelectionBounds() {
			return selectionBounds;
		}
		protected void updateSelectionBounds() {
			if (isSelected()) {
				int hand1=startSelection.getHand().getNumber();
				int hand2=endSelection.getHand().getNumber();
				int x1,y1,x2,y2;
				x1=getLeftGridX(Math.min(startSelection.getTime(),endSelection.getTime()));
				x2=getRightGridX(Math.max(startSelection.getTime(),endSelection.getTime()));
				y1=getTopGridY(Math.min(hand1,hand2));
				y2=getBottomGridY(Math.max(hand1,hand2));;
				selectionBounds=new Rectangle(x1,y1,x2-x1,y2-y1);
				//System.out.println("hand1="+hand1);
				//System.out.println("hand2="+hand2);
//				System.out.println(startSelection);
//				System.out.println(endSelection);
			} else {
				selectionBounds=null;
			}
		}
		public void startSelection(EndPoint endPoint) {
			startSelection=endPoint;
			endSelection=endPoint;
			updateSelectionBounds();
			setChanged();
			notifyObservers();
		}
		public void updateSelection(EndPoint endPoint) {
			if (!endSelection.equals(endPoint)) {
				endSelection=endPoint;
				updateSelectionBounds();
				setChanged();
				notifyObservers();
			}
		}
		public void clearSelection() {
			startSelection(EndPoint.INVALID_ENDPOINT);
		}
		public boolean isSelected() {
			return (startSelection.isValid()  && endSelection.isValid());
		}
		public PassCollection getSelection() {
			if (isSelected()) return new PassCollection(startSelection,endSelection);
			return PassCollection.EMPTY_COLLECTION;
		}
	}
	PatternController patternController;
	Observer patternObserver;
	SelectionModel selectionModel=new SelectionModel();
	
	EndPoint dragEndPoint;

	Point selectionStartPoint;
	int minTime=20;
	int totalTime=0;
	int handCount=0;
	
	int beatPixels=20;
	int laneBorder=20;
	int laneSize=80;
	int leftBorder=30;
	int rightBorder=30;
	int topBorder=30;
	int bottomBorder=30;
	int endPointDiameter=10;
	// selection rectangle dimension
	int sW=2;
	int sH=2;
	boolean showGrid=true;
	boolean labelPasses=true;

	Color bgColor=Color.white;
	Color fgColor=Color.black;
	Color selectionColor=Color.lightGray;
	Color unknownBallColor=Color.black;
	Color[] ballColors={Color.red,Color.orange,Color.yellow,Color.green,Color.blue,Color.cyan,Color.magenta};

	Image ladderImage=null;
	Graphics ladderG=null;

	int w,h;

	//Hashtable handToNumber=new Hashtable();

	LadderDiagram(/*PatternController patternController*/) {
		setBackground(bgColor);
		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				handleMousePressed(e,getEndPoint(e.getPoint()));
			}
			public void mouseReleased(MouseEvent e) {
				handleMouseReleased(e,getEndPoint(e.getPoint()));
			}
		});
		addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseMoved(MouseEvent e) {
				int c=Cursor.DEFAULT_CURSOR;
				if (isOverEndPoint(e.getPoint(),getEndPoint(e.getPoint()))) {
					c=Cursor.HAND_CURSOR;
				}
				if (getCursor().getType()!=c) setCursor(Cursor.getPredefinedCursor(c));
			}
			
			public void mouseDragged(MouseEvent e) {
				if (mode==SELECTING) {
					selectionModel.updateSelection(getEndPoint(e.getPoint()));
				}
			}
			
		});
		selectionModel.addObserver(new Observer() {
			public void update(Observable ob,Object o) {
				paintLadder(ladderG);
				repaint();
			}
		});
//		setController(patternController);
	}
	protected int getTotalTime(Pattern pattern) {
		return Math.max(pattern.getMaxTime()+pattern.getMaxBeats(),minTime);
	}
	public void setController(PatternController controller) {
		if (patternController!=null) patternController.deleteObserver(patternObserver);
		this.patternController=controller;
		if (controller!=null) {
			this.patternObserver=new Observer() {
				public void update(Observable ob,Object o) {
					patternUpdate(((PatternController)ob).getPattern());
				}
			};
			controller.addObserver(patternObserver);
			patternUpdate(controller.getPattern());
		}
	}
	public void patternUpdate(Pattern pattern) {
		selectionModel.clearSelection();
		if (pattern.getHandCount()!=handCount || getTotalTime(pattern)!=totalTime) {
			totalTime=getTotalTime(pattern);
			w=beatPixels*totalTime+leftBorder+rightBorder;
			h=(laneBorder*2+laneSize)*pattern.getJugglerCount()+topBorder+bottomBorder;
			setSize(w,h);
			if (getParent()!=null) {
				// resize ScrollPane parent
				getParent().doLayout();
				getParent().validate();
			}
			/*
			// create mapping Hand to number
			handToNumber.clear();
			for (int hand=0;hand<pattern.getHandCount();hand++) {
				handToNumber.put(pattern.getHand(hand),new Integer(hand));
			}
			*/
		}
		paintLadder(ladderG);
		repaint();
	}
	public SelectionModel getSelectionModel() {
		return selectionModel;
	}
	protected Pattern getPattern() {
		return patternController.getPattern();
	}
	protected void drawPass(Graphics g,EndPoint passPoint) {
		EndPoint catchPoint=passPoint.getNextEndPoint();
		Pass pass=passPoint.getPass();
		int x1=getX(passPoint.getTime());
		int y1=getY(passPoint.getHand());
		int x2=getX(catchPoint.getTime());
		int y2=getY(catchPoint.getHand());
		double x=(double)(x2-x1);
		double y=(double)(y2-y1);
		double r=(double)endPointDiameter;
		// adjust to circles
		double adjX=r/Math.sqrt(1.0d+y*y/(x*x));
		double adjY=r/Math.sqrt(1.0d+x*x/(y*y));
		if (x2<x1) adjX=-adjX;
		if (y2<y1) adjY=-adjY;
		// label pass
		if (labelPasses) {
			g.setColor(fgColor);
			String label=Integer.toString(pass.getBeats());
			// correct according to rhythm
			Rhythm handRhythm=passPoint.getHand().getRhythm();
			float ratio=2.0f*(float)handRhythm.getBeatsPerRepeat()/(float)handRhythm.getRepeatLength();
			if (ratio!=1.0f) label=Float.toString((float)pass.getBeats()*ratio);
			if ( !passPoint.getHand().getJuggler().equals(catchPoint.getHand().getJuggler()) || 
				( passPoint.getPass().isSelf() && passPoint.getPass().isRtoLorLtoR()
				&& passPoint.getHand().getOther().isBeat(passPoint.getTime()) ) ) {
				// pass or synchro crossing throw
				label+="x";
			}
			int labelWidth=g.getFontMetrics().stringWidth(label);
			int labelHeight=g.getFontMetrics().getHeight();
			if (passPoint.getHand().isRight())
				g.drawString(label,x1-labelWidth/2,y1+endPointDiameter+labelHeight);
			else
				g.drawString(label,x1-labelWidth/2,y1-endPointDiameter-labelHeight/2);
		}
		x1=x1+(int)adjX;
		y1=y1+(int)adjY;
		x2=x2-(int)adjX;
		y2=y2-(int)adjY;
		g.setColor(getEndPointColor(passPoint));
		g.drawLine(x1,y1,x2,y2);
		// draw arrowhead
		g.fillPolygon(new int[]{x2,x2-(int)adjX-(int)adjY,x2-(int)adjX+(int)adjY},new int[]{y2,y2-(int)adjY+(int)adjX,y2-(int)adjY-(int)adjX},3);
	}
	Color getEndPointColor(EndPoint endPoint) {
		Ball ball=endPoint.getBall();
		if (ball.noBall()) {
			if (!endPoint.getCatch().noPass() || !endPoint.getPass().noPass()) return unknownBallColor;
			return bgColor;
		}
		return ballColors[ball.getNumber()%ballColors.length];
	}
	void drawEndPoint(Graphics g,EndPoint endPoint) {
		int x=getX(endPoint.getTime())-endPointDiameter/2;
		int y=getY(endPoint.getHand())-endPointDiameter/2;
		int w=endPointDiameter;
		int h=endPointDiameter;

		// colour according to caught ball
		g.setColor(getEndPointColor(endPoint));
		g.fillOval(x,y,w,h);
		Pass pass=endPoint.getPass();
		if (!pass.noPass()) {
			drawPass(g,endPoint);
		}
		// draw outline
		g.setColor(fgColor);
		g.drawOval(x,y,w,h);

		/*
		if (selectionModel.isSelected(endPoint)) {
			// selected end point
			// draw boxes
			g.setColor(fgColor);
			g.fillRect(x,y,sW,sH);
			g.fillRect(x+w,y,sW,sH);
			g.fillRect(x,y+h,sW,sH);
			g.fillRect(x+w,y+h,sW,sH);
		}
		*/
	}
	/*
	protected int getHandNumber(Hand hand) {
		return ((Integer)handToNumber.get(hand)).intValue();
	}
	*/
	int getX(int time) {
		return leftBorder+time*beatPixels+beatPixels/2;
	}
	int getY(Hand hand) {
		int n=hand.getNumber();
		return topBorder+(n/2)*(laneBorder*2+laneSize)+laneBorder+(n%2)*laneSize;
	}
	protected int getLeftGridX(int time) {
		return leftBorder+time*beatPixels;
	}
	protected int getRightGridX(int time) {
		return getLeftGridX(time+1);
	}
	protected int getTopGridY(int hand) {
		return topBorder+hand*(laneBorder+laneSize/2);
	}
	protected int getBottomGridY(int hand) {
		return getTopGridY(hand+1);
	}
	// returns nearest endpoint
	protected EndPoint getEndPoint(Point xy) {
		Hand hand=getHand(xy.y);
		if (hand==null) return EndPoint.INVALID_ENDPOINT;
		int time=getTime(xy.x);
		if (time==-1) return EndPoint.INVALID_ENDPOINT;
		EndPoint endPoint=hand.getEndPoint(time);
		return endPoint;
	}
	protected boolean isOverEndPoint(Point p,EndPoint endPoint) {
		return (endPoint.isBeat() && Math.abs(p.y-getY(endPoint.getHand()))<=endPointDiameter && Math.abs(p.x-getX(endPoint.getTime()))<=endPointDiameter);
	}
	protected Hand getHand(int y) {
		if (y<topBorder) return null;
		if (y>(h-bottomBorder)) return null;
		for (int i=0;i<getPattern().getHandCount();i++) {
			if (y<getBottomGridY(i)) return getPattern().getHand(i);
		}
		return null;
	}
	int getTime(int x) {
		if (x<leftBorder || x>(w-rightBorder)) return -1;
		for (int time=0;time<totalTime;time++) {
			if (x<getRightGridX(time)) return time;
		}
		return -1;
	}
	public void paintLadder(Graphics g) {
		if (g==null) return;
		g.setColor(bgColor);
		g.fillRect(0,0,w,h);
		if (getPattern().getJugglerCount()==0) return;
		Rectangle rect=selectionModel.getSelectionBounds();
		if (rect!=null) {
			g.setColor(selectionColor);
			g.fillRect(rect.x,rect.y,rect.width,rect.height);
		}
		if (showGrid) {
			g.setColor(fgColor);
			for (int t=0;t<=totalTime;t++) {
				//g.drawLine(leftBorder-beatPixels/2+t*beatPixels,topBorder,leftBorder-beatPixels/2+t*beatPixels,h-bottomBorder);
				int x=getLeftGridX(t);
				g.drawLine(x,topBorder,x,h-bottomBorder);
			}
			for (int j=0;j<=getPattern().getJugglerCount();j++) {
				int y=getTopGridY(j*2);  // by hand NOT juggler
				//g.drawLine(leftBorder-beatPixels/2,topBorder+j*(laneBorder*2+laneSize),w-rightBorder+beatPixels/2,topBorder+j*(laneBorder*2+laneSize));
				g.drawLine(leftBorder,y,w-rightBorder,y);
			}
		}
		for (int t=0;t<totalTime;t++) {
			for (int h=0;h<getPattern().getHandCount();h++) {
				EndPoint endPoint=getPattern().getHand(h).getEndPoint(t);
				if (endPoint.isBeat()) {
					drawEndPoint(g,endPoint);
				}				
			}			
		}
	}
	public void paint(Graphics g) {
		update(g);
	}
	public void update(Graphics g) {
		if (ladderImage==null || ladderImage.getWidth(this)!=w || ladderImage.getHeight(this)!=h) {
			ladderImage=createImage(w,h);
			ladderG=ladderImage.getGraphics();
			paintLadder(ladderG);
		}
		g.drawImage(ladderImage,0,0,this);
	}
	public Dimension getMaximumSize() {
		return getSize();
	}
	public Dimension getSize() {
		return new Dimension(w,h);
	}
	protected void handleMousePressed(MouseEvent e,EndPoint endPoint) {
		if (endPoint.isValid()) {
			//System.out.println("MousePressed:"+e.getX()+":"+e.getY()+":hand="+endPoint.getHand().getNumber());
			int yTop=topBorder+endPoint.getHand().getNumber()*(laneBorder+laneSize/2);
			int yBottom=bottomBorder+(endPoint.getHand().getNumber()+1)*(laneBorder+laneSize/2);
			//System.out.println("YTOP="+yTop);
			//System.out.println("YBOTTOM="+yBottom);
			//for (int i=0;i<getPattern().getHandCount();i++) System.out.println("Hand "+i+"="+getPattern().getHand(i).getNumber());
		}
		if (isOverEndPoint(e.getPoint(),endPoint)) {
			dragEndPoint=endPoint;
			mode=PASSING;
		} else {
			selectionModel.startSelection(endPoint);
			mode=SELECTING;
		}
	}
	protected void handleMouseReleased(MouseEvent e,EndPoint dropEndPoint) {
		if (mode==PASSING) {
			if (dropEndPoint.equals(dragEndPoint)) {
				// simple click, select endpoint instead
				selectionModel.startSelection(dropEndPoint);
				selectionModel.updateSelection(dropEndPoint);
			} else 	if (isOverEndPoint(e.getPoint(),dropEndPoint)) {
				if (!addPass(dragEndPoint,dropEndPoint) && !swapIncoming(dragEndPoint,dropEndPoint) && ! swapOutgoing(dragEndPoint,dropEndPoint)) {
					passingFailed(dragEndPoint,dropEndPoint); // t1==t2
				}
				/*
				if (dropEndPoint.getTime()>dragEndPoint.getTime()) {
					if (!patternController.addPass(dragEndPoint,dropEndPoint)) passingFailed(dragEndPoint,dropEndPoint);
				} else if (dragEndPoint.getTime()>dropEndPoint.getTime()) {
					if (!patternController.addPass(dropEndPoint,dragEndPoint)) passingFailed(dropEndPoint,dragEndPoint);
				} else {
					passingFailed(dragEndPoint,dropEndPoint); // t1==t2
				}
				*/
			}
		} else if (mode==SELECTING) {
			selectionModel.updateSelection(dropEndPoint);
		}
		mode=DEFAULT;
	}
	protected boolean addPass(EndPoint endPointA,EndPoint endPointB) {
		if (endPointA.getTime()>endPointB.getTime()) {
			return (patternController.addPass(endPointB,endPointA));
		} else if (endPointB.getTime()>endPointA.getTime()) {
			return (patternController.addPass(endPointA,endPointB));
		} else {
			return false;
		}
	}
	protected void passingFailed(EndPoint endPointA,EndPoint endPointB) {
//		System.out.println("Failed to pass:"+endPointA+","+endPointB);
	}
	protected boolean swapIncoming(EndPoint endPointA,EndPoint endPointB) {
		// try to swap passes
		EndPoint passPointA=endPointA.getPreviousEndPoint();
		EndPoint passPointB=endPointB.getPreviousEndPoint();
		if (passPointA.isValid() && passPointB.isValid()) {
			if (passPointA.getTime()<endPointB.getTime() && passPointB.getTime()<endPointA.getTime()) {
				// we can swap these throws
				patternController.startMultipleChanges();
				patternController.removePass(passPointA);
				patternController.removePass(passPointB);
				patternController.addPass(passPointA,endPointB);
				patternController.addPass(passPointB,endPointA);
				patternController.finishMultipleChanges();
				return true;
			}
		}
		return false;
	}
	protected boolean swapOutgoing(EndPoint endPointA,EndPoint endPointB) {
		// try to swap passes
		EndPoint catchPointA=endPointA.getNextEndPoint();
		EndPoint catchPointB=endPointB.getNextEndPoint();
		if (catchPointA.isValid() && catchPointB.isValid()) {
			if (catchPointA.getTime()>endPointB.getTime() && catchPointB.getTime()>endPointA.getTime()) {
				// we can swap these throws
				patternController.startMultipleChanges();
				patternController.removePass(endPointA);
				patternController.removePass(endPointB);
				patternController.addPass(endPointA,catchPointB);
				patternController.addPass(endPointB,catchPointA);
				patternController.finishMultipleChanges();
				return true;
			}
		}
		return false;
	}
}
