package animation;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class AnimationCanvas extends Canvas implements Runnable {

	Thread animationThread;
	int framesPerSecond; // default 10 frames per second
	long frameDuration;
	long startTime=0;
	long pauseTime=0;
	long totalTime=10000; // 10 seconds duration (10 000 milliseconds)
	int frameNo=0;
	boolean stop=false;

	AnimationObservable animationObservable=new AnimationObservable();

	Image animationImage;
	Graphics animationG;
	
	class AnimationObservable extends Observable {
		protected void postAnimationEvent() {
			setChanged();
			notifyObservers();
		}
	}
	protected AnimationCanvas() {
		setFramesPerSecond(20);
	}
	public void setFramesPerSecond(int frames) {
		framesPerSecond=frames;
		frameDuration=(long)(1000/frames);
	}

	public void setTotalTime(long time) {
		this.totalTime=time;
	}
	public long getFrameTime(int frameNo) {
		return frameNo*frameDuration;
	}
	public long getWaitTime(int frameNo) {
		long nextFrameTime=startTime+getFrameTime(frameNo);
		return Math.max(0,nextFrameTime-System.currentTimeMillis());
	}
	public long getTotalTime() {
		return totalTime;
	}
	public long getElapsedTime() {
		if (isPaused()) return pauseTime-startTime;
		if (startTime>0) return Math.min(totalTime,System.currentTimeMillis()-startTime);
		return 0;
	}
	// from start
	public void play() {
		frameNo=0;
		startTime=System.currentTimeMillis();
		pauseTime=0;
		start();
	}
	public void pause() {
		if (pauseTime>0) { // unpause
			startTime=startTime+(System.currentTimeMillis()-pauseTime);
			pauseTime=0;
			start();
		} else { // pause
			pauseTime=System.currentTimeMillis();
		}
	}
	public void start() {
		if (animationThread==null) {
			stop=false;
			animationThread=new Thread(this);
			animationThread.start();
			animationObservable.postAnimationEvent();
		}
	}
	public void run() {
		try {
			while (!isStopped() && !isPaused() && getElapsedTime()<getTotalTime()) {
				repaint();
				Thread.currentThread().sleep(getWaitTime(frameNo));
				frameNo++;
			}
		} catch (InterruptedException ex) {
		}
		animationThread=null;
		repaint();
		animationObservable.postAnimationEvent();
	}
	public void stop() {
		stop=true;
	}
	public boolean isStopped() {
		return stop;
	}
	public boolean isPaused() {
		return (pauseTime>0);
	}
	public boolean hasFinished() {
		return (getTotalTime()<getElapsedTime());
	}
	public void paint(Graphics g) {
		update(g);
	}
	public void update(Graphics g) {
		if (g==null) return;
		if (animationImage==null || animationImage.getWidth(this)!=getSize().width || animationImage.getHeight(this)!=getSize().height) {
			animationImage=createImage(getWidth(),getHeight());
			animationG=animationImage.getGraphics();
		}
		renderBackground(animationG);
		render(animationG,getFrameTime(frameNo));
		g.drawImage(animationImage,0,0,this);
	}
	protected void renderBackground(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0,0,animationImage.getWidth(this),animationImage.getHeight(this));
		g.setColor(getForeground());
	}
	protected void render(Graphics g,long time) {
		String timeStr="Elapsed Time:"+time/1000+"/"+getTotalTime()/1000;
		g.drawString(timeStr,100,100);
	}
		/* for testing purposes
	public static void main(String[] args) {
		Frame frame=new Frame();
		frame.setLayout(new GridLayout(1,1));
		AnimationCanvas animation=new AnimationCanvas(60,30000);
		animation.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				((AnimationCanvas)e.getSource()).pause();
			}
		});
		frame.add(animation);
		frame.setSize(300,300);
		frame.setVisible(true);
		animation.play();
	}
		 */
} 
