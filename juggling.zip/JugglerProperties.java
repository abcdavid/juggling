import juggling.*;;

public class JugglerProperties extends java.awt.Dialog {

	PatternController controller;
	Juggler juggler;
	int maxBalls=9;
	String[] rhythms={"x_","_x","x___","_x__","__x_","___x"};

    	JugglerProperties(java.awt.Frame parent,PatternController controller,Juggler juggler) {
		super(parent, true);
		initComponents();
		update(controller,juggler);
	}
	public void update(PatternController controller,Juggler juggler) {
		this.controller=controller;
		this.juggler=juggler;
		ballNumberRHChoice.select(Integer.toString(juggler.getRightHand().getBallCount()));
		ballNumberLHChoice.select(Integer.toString(juggler.getLeftHand().getBallCount()));
		rhRhythmChoice.select(juggler.getRightHand().getRhythm().toString());
		lhRhythmChoice.select(juggler.getLeftHand().getRhythm().toString());
	}

	private void initComponents() {
		java.awt.GridBagConstraints gridBagConstraints;
		
		jugglerLabel = new java.awt.Label();
		ballsRHLabel = new java.awt.Label();
		ballsLHLabel = new java.awt.Label();
		ballNumberRHChoice = new java.awt.Choice();
		ballNumberLHChoice = new java.awt.Choice();
		rhRhythmLabel = new java.awt.Label();
		rhRhythmChoice = new java.awt.Choice();
		lhRhythmLabel = new java.awt.Label();
		lhRhythmChoice = new java.awt.Choice();
		buttonPanel = new java.awt.Panel();
		okButton = new java.awt.Button();
		cancelButton = new java.awt.Button();
		
		setLayout(new java.awt.GridBagLayout());
		
		setModal(true);
		setResizable(false);
		setTitle("Juggler Properties");
		addWindowListener(new java.awt.event.WindowAdapter() {
		    public void windowClosing(java.awt.event.WindowEvent evt) {
			closeDialog();
		    }
		});

		for (int i=0;i<maxBalls;i++) {
			String b=Integer.toString(i);
		    ballNumberRHChoice.add(b);
		    ballNumberLHChoice.add(b);
		}
		for (int r=0;r<rhythms.length;r++) {
		    rhRhythmChoice.add(rhythms[r]);
		    lhRhythmChoice.add(rhythms[r]);
		}

		jugglerLabel.setAlignment(java.awt.Label.CENTER);
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 0;
		gridBagConstraints.gridwidth = 2;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(jugglerLabel, gridBagConstraints);
		
		ballsRHLabel.setAlignment(java.awt.Label.RIGHT);
		ballsRHLabel.setText("Number of Balls (Right):");
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 1;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(ballsRHLabel, gridBagConstraints);
		
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.gridy = 1;
		add(ballNumberRHChoice, gridBagConstraints);
		
		ballsLHLabel.setAlignment(java.awt.Label.RIGHT);
		ballsLHLabel.setText("Number of Balls (Left):");
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 2;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(ballsLHLabel, gridBagConstraints);
		
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.gridy = 2;
		add(ballNumberLHChoice, gridBagConstraints);
		
		rhRhythmLabel.setAlignment(java.awt.Label.RIGHT);
		rhRhythmLabel.setText("Right Hand Rhythm:");
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 3;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(rhRhythmLabel, gridBagConstraints);
		
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.gridy = 3;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(rhRhythmChoice, gridBagConstraints);
		
		lhRhythmLabel.setAlignment(java.awt.Label.RIGHT);
		lhRhythmLabel.setText("Left Hand Rhythm:");
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 4;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(lhRhythmLabel, gridBagConstraints);
		
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.gridy = 4;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		add(lhRhythmChoice, gridBagConstraints);
		
		okButton.setLabel("OK");
		okButton.addActionListener(new java.awt.event.ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent evt) {
			okPressed(evt);
		    }
		});
		buttonPanel.add(okButton);
		
		cancelButton.setLabel("Cancel");
		cancelButton.addActionListener(new java.awt.event.ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent evt) {
			closeDialog();
		    }
		});
		
		buttonPanel.add(cancelButton);
		
		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 5;
		gridBagConstraints.gridwidth = 2;
		add(buttonPanel, gridBagConstraints);
		
		pack();
	}

	private void okPressed(java.awt.event.ActionEvent evt) {
		// set juggler properties
		juggler.getRightHand().setRhythm(Rhythm.getRhythm(rhRhythmChoice.getSelectedItem()));
		juggler.getLeftHand().setRhythm(Rhythm.getRhythm(lhRhythmChoice.getSelectedItem()));
		juggler.getRightHand().setBallCount(Integer.valueOf(ballNumberRHChoice.getSelectedItem()).intValue());
		juggler.getLeftHand().setBallCount(Integer.valueOf(ballNumberLHChoice.getSelectedItem()).intValue());
		controller.patternChanged();
		setVisible(false);
		dispose();
	}
	private void closeDialog() {
		setVisible(false);
		dispose();
	}

    
    private java.awt.Choice lhRhythmChoice;
    private java.awt.Panel buttonPanel;
    private java.awt.Button okButton;
    private java.awt.Choice rhRhythmChoice;
    private java.awt.Choice ballNumberRHChoice;
    private java.awt.Choice ballNumberLHChoice;
    private java.awt.Label rhRhythmLabel;
    private java.awt.Label lhRhythmLabel;
    private java.awt.Button cancelButton;
    private java.awt.Label jugglerLabel;
    private java.awt.Label ballsRHLabel;
    private java.awt.Label ballsLHLabel;
    
}
