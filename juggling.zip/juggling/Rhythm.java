package juggling;

public class Rhythm {

	boolean[] beats;
	int struck=0;

	Rhythm(String text) {
		beats=new boolean[text.length()];
		text=text.toLowerCase();
		for (int i=0;i<text.length();i++) {
			beats[i]=(text.charAt(i)=='x');
			if (beats[i]) {
				struck++;
			}
			
		}	
	}
	public static Rhythm getRhythm(String text) {
		return new Rhythm(text);
	}
	public String toString() {
		StringBuffer buf=new StringBuffer();
		buf.setLength(beats.length);
		for (int i=0;i<beats.length;i++) {
			buf.setCharAt(i,beats[i]?'x':'_');
		}
		return buf.toString();
	}
	public boolean isBeat(int beat) {
		return beats[beat%beats.length];
	}
// how many
	public int getBeatNumber(int beat) {
		// calculate complete cycles
		int cycleNo=beat/beats.length;
		int count=cycleNo*struck;
		int extra=beat%beats.length;
		for (int i=0;i<extra;i++) {
			if (beats[i]) count++;
		}
		return count-1;
	}
	public int getRepeatLength() {
		return beats.length;
	}
	public int getBeatsPerRepeat() {
		return struck;
	}
}
