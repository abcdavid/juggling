package juggling;

public class NotEndPointException extends RuntimeException {
	NotEndPointException(Hand hand,int time) {
	}
}
