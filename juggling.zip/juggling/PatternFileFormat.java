package juggling;

import java.io.*;

public class PatternFileFormat implements FileFormat {
	public Pattern readInputStream(InputStream input) throws IOException {
		return PatternParser.readPattern(input);
		/*
		Pattern pattern=new Pattern();
		SiteswapParser.openPattern(input,pattern,0);
		return pattern;
		*/
	}
	public void writeOutputStream(OutputStream output,Pattern pattern) throws IOException {
		BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(output));
		String nl=System.getProperty("line.separator");
		int jCount=pattern.getJugglerCount();
		writer.write("jugglers {"+jCount+"}// number of jugglers"+nl);
		writer.write("hands ");
		for (int j=0;j<jCount;j++) {
			Juggler juggler=pattern.getJuggler(j);
			writer.write("{"+juggler.getRightHand().getRhythm().toString()+"}// right hand rhythm"+nl);
			writer.write("{"+juggler.getLeftHand().getRhythm().toString()+"}// left hand rhythm"+nl);
		}
		writer.write("balls {");
		for (int i=0;i<jCount;i++) {
			writer.write(" "+Integer.toString(pattern.getJuggler(i).getRightHand().getBallCount())+" "+Integer.toString(pattern.getJuggler(i).getLeftHand().getBallCount()));
		}
		writer.write(" }"+nl);
		writer.write("passes ");
		for (int h=0;h<pattern.getHandCount();h++) {
			writer.write("{ ");
			Hand hand=pattern.getHand(h);
			int time=0;
			while (time<pattern.getMaxPassTime()) {
				if (hand.isBeat(time)) {
					Pass pass=hand.getPass(time);
					String passStr;
					if (pass.noPass()) {
						passStr="0";
					} else {
						passStr=Integer.toString(pass.getBeats())+","+Integer.toString(pass.getToHand().getNumber());
					}
					writer.write(passStr+" ");
				}
				time++;
			}
			writer.write("}"+nl);
		}
		writer.flush();
		writer.close();
	}
}
