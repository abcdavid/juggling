// $ANTLR 2.7.1: "juggling/siteswap.g" -> "SiteswapParser.java"$
package juggling;

import java.io.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class SiteswapParser extends antlr.LLkParser
       implements SiteswapParserTokenTypes
 {
	
	public static Pattern readSiteswap(String siteswap) throws ANTLRException {
		SiteswapLexer lexer = new SiteswapLexer(new StringReader(siteswap));
		TokenBuffer buffer = new TokenBuffer(lexer);
		SiteswapParser parser = new SiteswapParser(buffer);
		Pattern pattern=new Pattern();
		parser.siteswap(pattern,0);
		return pattern;
	}
	public static void openPattern(InputStream input,Pattern pattern,int startTime) throws ANTLRException {
		SiteswapLexer lexer = new SiteswapLexer(new InputStreamReader(input));
		TokenBuffer buffer = new TokenBuffer(lexer);
		SiteswapParser parser = new SiteswapParser(buffer);
		parser.siteswap(pattern,startTime);
	}
	

protected SiteswapParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public SiteswapParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected SiteswapParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public SiteswapParser(TokenStream lexer) {
  this(lexer,1);
}

public SiteswapParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void siteswap(
		Pattern pattern,int startTime
	) throws RecognitionException, TokenStreamException {
		
		
		comments();
		{
		switch ( LA(1)) {
		case DIGIT:
		{
			simple(pattern,startTime);
			break;
		}
		case LP:
		{
			synchro(pattern,startTime);
			break;
		}
		case LT:
		{
			passing(pattern,startTime);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(Token.EOF_TYPE);
	}
	
	public final void comments() throws RecognitionException, TokenStreamException {
		
		
		{
		_loop5:
		do {
			switch ( LA(1)) {
			case SL_COMMENT:
			{
				match(SL_COMMENT);
				break;
			}
			case ML_COMMENT:
			{
				match(ML_COMMENT);
				break;
			}
			default:
			{
				break _loop5;
			}
			}
		} while (true);
		}
	}
	
	public final void simple(
		Pattern pattern,int startTime
	) throws RecognitionException, TokenStreamException {
		
		Token  d = null;
		
		Juggler juggler=pattern.addJuggler();
		int totalBeats=0;
		int beatCount=0;
		int time=startTime;
		
		
		{
		int _cnt8=0;
		_loop8:
		do {
			if ((LA(1)==DIGIT)) {
				d = LT(1);
				match(DIGIT);
				
					int beats=Integer.valueOf(d.getText()).intValue();
					Hand fromHand;
					if (time%2==0) fromHand=pattern.getJuggler(0).getRightHand();
					else fromHand=pattern.getJuggler(0).getLeftHand();
					Hand toHand;
					if (beats%2==0) toHand=fromHand;
					else toHand=fromHand.getOther();
					EndPoint passPoint=fromHand.getEndPoint(time);
					EndPoint catchPoint=toHand.getEndPoint(time+beats);
					if (beats>0 && passPoint.makePass(catchPoint).noPass()) System.out.println("Failed to pass:time="+time+",beats="+beats);
					time++;
					totalBeats+=beats;
					beatCount++;
				
			}
			else {
				if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt8++;
		} while (true);
		}
		
			int ballCount=totalBeats/beatCount;
			juggler.getRightHand().setBallCount(ballCount/2+ballCount%2);
			juggler.getLeftHand().setBallCount(ballCount/2);
		
	}
	
	public final void synchro(
		Pattern pattern,int startTime
	) throws RecognitionException, TokenStreamException {
		
		Token  dR = null;
		Token  dL = null;
		
		int time=startTime;
		Juggler juggler=pattern.addJuggler();
		juggler.getLeftHand().setRhythm(juggler.getRightHand().getRhythm());
		boolean leftCrossed;
		boolean rightCrossed;
		int leftBeats;
		int rightBeats;
		int totalBeats=0;
		int beatCount=0;
		
		
		{
		int _cnt14=0;
		_loop14:
		do {
			if ((LA(1)==LP)) {
				
					leftCrossed=false;
					rightCrossed=false;
				
				match(LP);
				dR = LT(1);
				match(DIGIT);
				rightBeats=Integer.valueOf(dR.getText()).intValue();
				{
				switch ( LA(1)) {
				case X:
				{
					match(X);
					rightCrossed=true;
					break;
				}
				case DIGIT:
				case COMMA:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case COMMA:
				{
					match(COMMA);
					break;
				}
				case DIGIT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				dL = LT(1);
				match(DIGIT);
				leftBeats=Integer.valueOf(dL.getText()).intValue();
				{
				switch ( LA(1)) {
				case X:
				{
					match(X);
					leftCrossed=true;
					break;
				}
				case RP:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(RP);
				
					if (rightBeats>0) {
						EndPoint passPoint=juggler.getRightHand().getEndPoint(time);
						EndPoint catchPoint;
						if (rightCrossed) {
							catchPoint=juggler.getLeftHand().getEndPoint(time+rightBeats);
						} else {
							catchPoint=juggler.getRightHand().getEndPoint(time+rightBeats);
						}
						if (passPoint.makePass(catchPoint).noPass()) System.out.println("Failed to pass:time="+time+",rightBeats="+rightBeats);
					}
					if (leftBeats>0) {
						EndPoint passPoint=juggler.getLeftHand().getEndPoint(time);
						EndPoint catchPoint;
						if (leftCrossed) {
							catchPoint=juggler.getRightHand().getEndPoint(time+leftBeats);
						} else {
							catchPoint=juggler.getLeftHand().getEndPoint(time+leftBeats);
						}
						if (passPoint.makePass(catchPoint).noPass()) System.out.println("Failed to pass:time="+time+",leftBeats="+leftBeats);
					}
					time+=2;
					totalBeats+=leftBeats;
					totalBeats+=rightBeats;
					beatCount+=2;
				
			}
			else {
				if ( _cnt14>=1 ) { break _loop14; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt14++;
		} while (true);
		}
		
			int ballCount=totalBeats/beatCount;
			juggler.getRightHand().setBallCount(ballCount/2+ballCount%2);
			juggler.getLeftHand().setBallCount(ballCount/2);
		
	}
	
	public final void passing(
		Pattern pattern,int startTime
	) throws RecognitionException, TokenStreamException {
		
		Token  dA = null;
		Token  dB = null;
		
			int time=startTime;
			Juggler aJuggler=pattern.addJuggler();
			Juggler bJuggler=pattern.addJuggler();
			int aBeats,bBeats;
			boolean aPass,bPass;
			int aTotalBeats=0,bTotalBeats=0;
			int beatCount=0;
		
		
		{
		int _cnt20=0;
		_loop20:
		do {
			if ((LA(1)==LT)) {
				
					aPass=false;
					bPass=false;
				
				match(LT);
				dA = LT(1);
				match(DIGIT);
				aBeats=Integer.valueOf(dA.getText()).intValue();
				{
				switch ( LA(1)) {
				case X:
				{
					match(X);
					aPass=true;
					break;
				}
				case DIGIT:
				case COMMA:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case COMMA:
				{
					match(COMMA);
					break;
				}
				case DIGIT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				dB = LT(1);
				match(DIGIT);
				bBeats=Integer.valueOf(dB.getText()).intValue();
				{
				switch ( LA(1)) {
				case X:
				{
					match(X);
					bPass=true;
					break;
				}
				case GT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(GT);
				
					Juggler aToJuggler,bToJuggler;
					EndPoint aPassPoint,bPassPoint,aCatchPoint,bCatchPoint;
					aTotalBeats+=aBeats;
					bTotalBeats+=bBeats;
					beatCount++;
					if (time%2==0) {
						aPassPoint=aJuggler.getRightHand().getEndPoint(time);
						bPassPoint=bJuggler.getRightHand().getEndPoint(time);
					} else {
						aPassPoint=aJuggler.getLeftHand().getEndPoint(time);
						bPassPoint=bJuggler.getLeftHand().getEndPoint(time);
					}
					if (aPass) aToJuggler=bJuggler;
					else aToJuggler=aJuggler;
					if (bPass) bToJuggler=aJuggler;
					else bToJuggler=bJuggler;
					if ((time+aBeats)%2==0)
						aCatchPoint=aToJuggler.getRightHand().getEndPoint(time+aBeats);
					else
						aCatchPoint=aToJuggler.getLeftHand().getEndPoint(time+aBeats);
					if ((time+bBeats)%2==0)
						bCatchPoint=bToJuggler.getRightHand().getEndPoint(time+bBeats);
					else
						bCatchPoint=bToJuggler.getLeftHand().getEndPoint(time+bBeats);
					if (aPassPoint.makePass(aCatchPoint).noPass()) System.out.println("Failed to pass:time="+time+",aBeats="+aBeats+",aPass="+aPass);
					if (bPassPoint.makePass(bCatchPoint).noPass()) System.out.println("Failed to pass:time="+time+",bBeats="+bBeats+",bPass="+bPass);
					time++;
				
			}
			else {
				if ( _cnt20>=1 ) { break _loop20; } else {throw new NoViableAltException(LT(1), getFilename());}
			}
			
			_cnt20++;
		} while (true);
		}
		
			int aBallCount=aTotalBeats/beatCount;
			int bBallCount=bTotalBeats/beatCount;
			aJuggler.getRightHand().setBallCount(aBallCount/2+aBallCount%2);
			aJuggler.getLeftHand().setBallCount(aBallCount/2);
			bJuggler.getRightHand().setBallCount(bBallCount/2+bBallCount%2);
			bJuggler.getLeftHand().setBallCount(bBallCount/2);
		
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"SL_COMMENT",
		"ML_COMMENT",
		"DIGIT",
		"LP",
		"X",
		"COMMA",
		"RP",
		"LT",
		"GT",
		"LETTER",
		"WS"
	};
	
	
	}
