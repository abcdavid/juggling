package juggling;

import java.util.Enumeration;

public class PassCollection {
	public static PassCollection EMPTY_COLLECTION=new PassCollection();
	public interface PassElement {
		public Pass getPass();
		public EndPoint getEndPoint();
	}
	
	Pattern pattern;
	int firstHand;
	int startTime;
	int hands;
	int beats;
	
	class PElement implements PassElement {
		int t,h;
		PElement(int t,int h) {
			this.t=t;
			this.h=h;
		}
		public Pass getPass() {
			return PassCollection.this.getPass(t,h);
		}
		public EndPoint getEndPoint() {
			return PassCollection.this.getEndPoint(t,h);
		}
	}
	
	Pass[][] passes;
	
	// empty collection
	private PassCollection() {
		hands=0;
		beats=0;
	}
	// usual constructor
	public PassCollection(EndPoint aEndPoint,EndPoint bEndPoint) {
		pattern=aEndPoint.getHand().getJuggler().getPattern();
		firstHand=Math.min(aEndPoint.getHand().getNumber(),bEndPoint.getHand().getNumber());
		int lastHand=Math.max(aEndPoint.getHand().getNumber(),bEndPoint.getHand().getNumber());
		startTime=Math.min(aEndPoint.getTime(),bEndPoint.getTime());
		int endTime=Math.max(aEndPoint.getTime(),bEndPoint.getTime());
		beats=endTime-startTime+1;
		hands=lastHand-firstHand+1;
		passes=new Pass[beats][];
		System.out.println("PassCollection:beats="+beats+",hands="+hands);
		System.out.println("aEndPoint.getHand().getNumber()="+aEndPoint.getHand().getNumber());
		System.out.println("aEndPoint.getTime()="+aEndPoint.getTime());
		System.out.println("bEndPoint.getHand().getNumber()="+bEndPoint.getHand().getNumber());
		System.out.println("bEndPoint.getTime()="+bEndPoint.getTime());
		for (int t=startTime;t<=endTime;t++) {
			passes[t-startTime]=new Pass[hands];
			for (int h=firstHand;h<=lastHand;h++) {
				passes[t-startTime][h-firstHand]=pattern.getHand(h).getEndPoint(t).getPass();
				System.out.println("passes["+(t-startTime)+"]["+(h-firstHand)+"]="+passes[t-startTime][h-firstHand]);
			}
		}
	}
	public boolean isEmpty() {
		return (hands==0 || beats==0);
	}
	public int getHands() {
		return hands;
	}
	public int getBeats() {
		return beats;
	}
	// time and hand are now relative
	public Pass getPass(int time,int hand) {
		return passes[time][hand];
	}
	// time and hand are now relative , but EndPoint is from original Pattern
	public EndPoint getEndPoint(int time,int hand) {
		return pattern.getHand(firstHand+hand).getEndPoint(time+startTime);
	}
	class ElementEnumeration implements Enumeration {
		int t=0,h=0;
		
		public boolean hasMoreElements() {
			return (t<beats && h<hands);
		}
		public Object nextElement() {
			return nextPassElement();
		}
		public PassElement nextPassElement() {
			if (!hasMoreElements()) return null;
			PassElement element=new PElement(t,h);
			h++;
			if (h==hands) {
				h=0;
				t++;
			}
			return element;
		}
	}
	public Enumeration elements() {
		return new ElementEnumeration();
	}
}
