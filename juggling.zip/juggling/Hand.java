package juggling;

import java.util.*;
import java.io.*;

public class Hand {

	Juggler juggler;
	Rhythm rhythm;
	Ball[] balls;
	int number;
//	PassSequence passSequence=new PassSequence();
//	PassSequence catchSequence=new PassSequence();

	Hashtable endPoints=new Hashtable();

	Hand(int number,Juggler juggler,Rhythm rhythm) {
		this.number=number;
		this.juggler=juggler;
		this.rhythm=rhythm;
	}
	public void setBallCount(int count) {
		if (count!=getBallCount()) {
			Ball[] newBalls=new Ball[count];
			for (int i=0;i<newBalls.length;i++) {
				if (balls!=null && i<balls.length) {
					newBalls[i]=balls[i];
				} else {
					newBalls[i]=juggler.getPattern().getNewBall();
				}
			}
			allocateBalls(balls,newBalls);
		}
	}
	public int getBallCount() {
		return (balls==null)?0:balls.length;
	}
	// assigns Balls to EndPoints
	protected void allocateBalls(Ball[] balls,Ball[] newBalls) {
		int ballNo=0;
		int t=0;
		// remove/replace existing balls
		while (balls!=null && ballNo<balls.length) {
			if (isBeat(t)) {
				Ball newBall=Ball.NO_BALL;
				if (newBalls!=null && ballNo<newBalls.length) newBall=newBalls[ballNo];
				getEndPoint(t).setBall(newBall);
				ballNo++;
			}
			t++;
		}
		// add any extra balls
		while (newBalls!=null && ballNo<newBalls.length) {
			if (isBeat(t)) {
				getEndPoint(t).setBall(newBalls[ballNo]);
				ballNo++;
			}
			t++;
		}
		this.balls=newBalls;
	}
	public String getLabel() {
		if (isLeft()) return "L";
		return "R";
	}
	public int getNumber() {
		return number;
	}
	protected void setNumber(int number) {
		this.number=number;
	}
	public Juggler getJuggler() {
		return juggler;
	}
	public boolean isLeft() {
		return juggler.getLeftHand().equals(this);
	}
	public boolean isRight() {
		return juggler.getRightHand().equals(this);
	}
	public void setRhythm(Rhythm rhythm) {
		//todo checks here - we can lose EndPoints and passes no on the new beat
		this.rhythm=rhythm;
	}
	public Rhythm getRhythm() {
		return rhythm;
	}
	public Hand getOther() {
		if (isRight()) return juggler.getLeftHand();
		return juggler.getRightHand();
	}
	public boolean isBeat(int time) {
		return rhythm.isBeat(time);
	}

	public synchronized EndPoint getEndPoint(int time) {
		//if (!isEndPoint(time)) return EndPoint.INVALID_ENDPOINT;
		Integer key=new Integer(time);
		if (endPoints.containsKey(key)) return (EndPoint)endPoints.get(key);
		EndPoint rtnEndPoint=new EndPoint(this,time);
		if (rtnEndPoint.isValid() && isBeat(time)) endPoints.put(key,rtnEndPoint);
		return rtnEndPoint;
	}
	public Pass getPass(int time) {
//		return passSequence.getPass(time);
		return getEndPoint(time).getPass();
	}
	public Pass getCatch(int time) {
//		return catchSequence.getPass(time);
		return getEndPoint(time).getCatch();
	}
	public Pass makePass(int time,int beats,Hand toHand) {
		EndPoint toEndPoint=toHand.getEndPoint(time+beats);
		EndPoint fromEndPoint=getEndPoint(time);
		return fromEndPoint.makePass(toEndPoint);
	}
	// removes all incoming and outgoing passes
	protected void removePasses() {
		for (int t=0;t<getJuggler().getPattern().getMaxTime();t++) {
			if (isBeat(t)) {
				Integer key=new Integer(t);
				if (endPoints.containsKey(key)) {
					EndPoint endPoint=(EndPoint)endPoints.get(key);
					EndPoint passPoint=endPoint.getPreviousEndPoint();
					// remove incoming pass
					if (passPoint.isValid()) passPoint.removePass();
					// remove outgoing pass
					endPoint.removePass();
					endPoints.remove(key); // to help garbage collector
				}
			}
		}
	}
	public void write(Writer out) throws IOException {
		for (int t=0;t<getJuggler().getPattern().getMaxTime();t++) {
			if (isBeat(t)) {
				out.write(getEndPoint(t).getPass().toString());
				out.write(" ");
			}
		}
		out.write(System.getProperty("line.separator"));
	}
}
