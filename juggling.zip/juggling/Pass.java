package juggling;

import java.io.*;

public class Pass {
	private Hand fromHand;
	private Hand toHand;
	private int beats;

	public static Pass NO_PASS=new Pass(null,null,0);

	Pass(Hand fromHand,Hand toHand,int beats) {
		this.fromHand=fromHand;
		this.toHand=toHand;
		this.beats=beats;
	}
	public Hand getFromHand() {
		return fromHand;
	}
	public Hand getToHand() {
		return toHand;
	}
	public Juggler getFromJuggler() {
		return fromHand.getJuggler();
	}
	public Juggler getToJuggler() {
		return toHand.getJuggler();
	}
	public int getBeats() {
		return beats;
	}
	public boolean isSelf() {
		if (noPass()) return false;
		return fromHand.getJuggler().equals(toHand.getJuggler());
	}
	public boolean isColumn() {
		if (noPass()) return false;
		return fromHand.equals(toHand);
	}
	public boolean isRtoRorLtoL() {
		if (noPass()) return false;
		return ((fromHand.isLeft() && toHand.isLeft()) || (fromHand.isRight() && toHand.isRight()));
	}
	public boolean isRtoLorLtoR() {
		if (noPass()) return false;
		return ((fromHand.isLeft() && toHand.isRight()) || (fromHand.isRight() && toHand.isLeft()));
	}
	public boolean noPass() {
		return this.equals(NO_PASS);
	}
	public String toString() {
		if (noPass()) return "0";
		return Integer.toString(getBeats())+getToHand().getJuggler().getLabel()+getToHand().getLabel();
	}
}
