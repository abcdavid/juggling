// $ANTLR 2.7.1: "juggling/pattern.g" -> "PatternParser.java"$
package juggling;

import java.io.*;

public interface PatternParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int JUGGLERS = 4;
	int LC = 5;
	int NUMBER = 6;
	int RC = 7;
	int HANDS = 8;
	int RHYTHM = 9;
	int BALLS = 10;
	int PASSES = 11;
	int COMMA = 12;
	int SL_COMMENT = 13;
	int ML_COMMENT = 14;
	int WS = 15;
}
