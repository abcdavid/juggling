package juggling;

import java.awt.*;
import java.util.Enumeration;

import animation.*;
import juggling.*;

public class PassingAnimation extends AnimationCanvas {
	Pattern pattern;
	long beatTime=300;  // how many milliseconds per beat

	//Dimension size=new Dimension(300,300);
	Point[] handCatchPoints;
	Point[] handPassPoints;
	Color[] ballColors={Color.red,Color.orange,Color.yellow,Color.green,Color.blue,Color.cyan,Color.magenta};
	int ballRadius=10;

	public PassingAnimation(Pattern pattern) {
		this.pattern=pattern;
		//setFramesPerSecond(10); // for testing
		setTotalTime((long)pattern.getMaxTime()*beatTime);
		setSize(300,300);
		initAnimation();
	}
	public void initAnimation() {
		// calculate positions of hands
		handPassPoints=new Point[pattern.getHandCount()];
		handCatchPoints=handPassPoints; // for now use the same
		// position jugglers in circle
		double radius=140.0d;
		double handSeparation=Math.PI/18.0d; // (2*handSeparation) ~=20 degrees between hands
		double radianSeparation=(2.0d*Math.PI)/(double)pattern.getJugglerCount();
		double rads=0.0d;
		double x,y;
		for (int j=0;j<pattern.getJugglerCount();j++) {
			double rRads=rads-handSeparation;
			double lRads=rads+handSeparation;
			x=radius*Math.cos(rRads);
			y=radius*Math.sin(rRads);
			handPassPoints[2*j]=new Point((int)x,(int)y);
			handPassPoints[2*j].translate(getSize().width/2,getSize().height/2);
			x=radius*Math.cos(lRads);
			y=radius*Math.sin(lRads);
			handPassPoints[2*j+1]=new Point((int)x,(int)y);
			handPassPoints[2*j+1].translate(getSize().width/2,getSize().height/2);
			rads+=radianSeparation;
		}
	}
	public void render(Graphics g,long time) {
		drawHands(g);
		long beatNo=time/beatTime;
		long remainder=time%beatTime;
	//	System.out.println("Rendering at time="+time+",beats="+beatNo);
		//double beatFraction=(double)remainder/(double)beatTime;
		Enumeration enum=pattern.getPassingEndPoints((int)beatNo);
		while (enum.hasMoreElements()) {
			EndPoint passPoint=(EndPoint)enum.nextElement();
		//	System.out.println("EndPoint time="+passPoint.getTime()+",ball="+passPoint.getBall()+",beats="+passPoint.getPass().getBeats());
			// calculate fraction of pass which has elapsed
			// how many beats since pass
			long wholeBeats=beatNo-(long)passPoint.getTime();
			long totalPassTime=(long)passPoint.getPass().getBeats()*beatTime;
			long elapsedPassTime=(long)wholeBeats*beatTime+remainder;
			double passFraction=(double)elapsedPassTime/(double)totalPassTime;
			Point fromPoint=handPassPoints[passPoint.getHand().getNumber()];
			Point toPoint=handCatchPoints[passPoint.getPass().getToHand().getNumber()];
			int x=fromPoint.x+(int)((double)(toPoint.x-fromPoint.x)*passFraction);
			int y=fromPoint.y+(int)((double)(toPoint.y-fromPoint.y)*passFraction);
			drawBall(g,x,y,passPoint.getBall());
		}
	}
	protected void drawBall(Graphics g,int x,int y,Ball ball) {
		g.setColor(ballColors[ball.getNumber()%ballColors.length]);
		g.fillOval(x-ballRadius,y-ballRadius,ballRadius*2,ballRadius*2);
	}
	protected void drawHands(Graphics g) {
		// simple crosses
		g.setColor(Color.black);
		for (int i=0;i<handPassPoints.length;i++) {
			g.drawLine(handPassPoints[i].x-2,handPassPoints[i].y,handPassPoints[i].x+2,handPassPoints[i].y);
			g.drawLine(handPassPoints[i].x,handPassPoints[i].y-2,handPassPoints[i].x,handPassPoints[i].y+2);
		}
	}
}
