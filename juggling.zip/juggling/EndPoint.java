package juggling;

import java.io.*;

public class EndPoint {
	private Hand hand;
	private int time;
	private Ball ball=Ball.NO_BALL;
	private Pass incoming=Pass.NO_PASS;
	private Pass outgoing=Pass.NO_PASS;

	public static EndPoint INVALID_ENDPOINT=new EndPoint(null,-1);

	EndPoint(Hand hand,int time) {
		this.hand=hand;
		this.time=time;
	}
	public int getTime() {
		return time;
	}
	public Hand getHand() {
		return hand;
	}
	public Juggler getJuggler() {
		return hand.getJuggler();
	}
	public Ball getBall() {
		return ball;
	}
	protected void setBall(Ball ball) {
		if (!this.ball.equals(ball)) {
			this.ball=ball;
			EndPoint nextEndPoint=getNextEndPoint();
			if (nextEndPoint.isBeat()) {
				nextEndPoint.setBall(ball);
			}
		}
	}
	protected void removeBall() {
		setBall(Ball.NO_BALL);
	}
	protected void setPass(Pass pass) {
		outgoing=pass;
	}
	protected void setCatch(Pass pass) {
		incoming=pass;
	}
	public boolean isValid() {
		//return (time>=0 && hand!=null && hand.isEndPoint(time));
		return (time>=0 && hand!=null);
	}
	public boolean isBeat() {
		return (isValid() && hand.isBeat(time));
	}
	public boolean equals(Object o) {
		if (o instanceof EndPoint) {
			EndPoint endPoint=(EndPoint)o;
			return (endPoint.time==time && ((hand!=null && endPoint.hand!=null && endPoint.hand.equals(hand)) || hand==null && endPoint.hand==null));
		}		
		return false;
	}
	public Pass getPass() {
		return outgoing;
		//return hand.getPass(time);
	}
	public Pass getCatch() {
		return incoming;
		//return hand.getCatch(time);
	}
	public EndPoint getNextEndPoint() {
		EndPoint nextEndPoint=INVALID_ENDPOINT;
//		Pass pass=getPass();
//		if (pass!=null) {
		if (!outgoing.noPass()) {
//			nextEndPoint=new EndPoint(pass.getToHand(),time+pass.getBeats());	
//			nextEndPoint=new EndPoint(outgoing.getToHand(),time+outgoing.getBeats());
			nextEndPoint=outgoing.getToHand().getEndPoint(time+outgoing.getBeats());
		}
		return nextEndPoint;
	}
	public EndPoint getPreviousEndPoint() {
		EndPoint previousEndPoint=INVALID_ENDPOINT;
//		Pass pass=getPass();
//		if (pass!=null) {
		if (!incoming.noPass()) {
//			nextEndPoint=new EndPoint(pass.getToHand(),time+pass.getBeats());	
//			nextEndPoint=new EndPoint(outgoing.getToHand(),time+outgoing.getBeats());
			previousEndPoint=incoming.getFromHand().getEndPoint(time-incoming.getBeats());
		}
		return previousEndPoint;
	}
	// todo make protected
	public Pass makePass(EndPoint endPoint) {
		// both end points must be valid
		// cannot be passing already
		// destination end point cannot be catching or holding a ball
		// must catch later than the throw
		if (isBeat() && endPoint.isBeat() && getPass().noPass() && endPoint.getCatch().noPass() && endPoint.getBall().noBall() && endPoint.time>time) {
			outgoing=new Pass(getHand(),endPoint.getHand(),endPoint.time-time);
			endPoint.incoming=outgoing;
			endPoint.setBall(ball);
			Pattern pattern=getHand().getJuggler().getPattern();
			if (pattern.getMaxTime()<endPoint.getTime()) pattern.setMaxTime(endPoint.getTime());
			return outgoing;
		}
		return Pass.NO_PASS;
	}
	public Pass removePass() {
		Pass pass=outgoing;
		if (!pass.noPass()) {
			EndPoint endPoint=getNextEndPoint();
			endPoint.incoming=Pass.NO_PASS;
			endPoint.setBall(Ball.NO_BALL);
			outgoing=Pass.NO_PASS;
			// todo update pattern max time
		}
		return pass;
//		return hand.removePass(time);
	}
	public String toString() {
		return "EndPoint{time="+time+",hand="+hand+",ball="+ball+"}";
	}
}
