package juggling;

// differs from pass - does not specify throwing or catching Hand,  nor Juggler?

public class Throw {
	int beats;
	
	Throw(int beats) {
		this.beats=beats;
	}
	public int getBeats() {
		return beats;
	}
	public boolean isRtoLorLtoR() {
		return beats%2==1;
	}
	public boolean isRtoRorLtoL() {
		return beats%2==0;
	}
}
