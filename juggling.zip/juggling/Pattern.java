package juggling;

import java.util.*;
import java.io.*;

public class Pattern {

	int maxTime=0; // use maximum height to increment
	int maxBeats=8; // maximum throw height
	Vector jugglers=new Vector();
//	Vector balls=new Vector();
	int ballCount=0;  // this is a count of balls allocated, but not necessarily the number of balls in the pattern

	public Pattern() {
	}
	/*
	public Pattern(int jugglerCount,int ballCount) {
		if (jugglerCount>0) {
			int ballsEach=ballCount/jugglerCount;
			int extras=ballCount%jugglerCount;
			for (int i=0;i<jugglerCount;i++) {
				int bCount=ballsEach;
				if (extras>0) {
					bCount++;
					extras--;
				}
				Ball[] ballArray=new Ball[bCount];
				for (int b=0;b<ballArray.length;b++) ballArray[b]=addBall();
				addJuggler().setStartingBalls(ballArray);
//				jugglers.addElement(new Juggler(ballArray));
			}
		}
	}
	*/
	public Juggler addJuggler() {
		Juggler juggler=new Juggler(jugglers.size(),this);
		jugglers.addElement(juggler);
		return juggler;
	}
	public boolean removeJuggler(Juggler juggler) {
		if (jugglers.removeElement(juggler)) {
			// remove any passes
			juggler.removePasses();
			// update numbering
			for (int i=0;i<jugglers.size();i++) {
				((Juggler)jugglers.elementAt(i)).setNumber(i);
			}
			return true;
		}
		return false;
	}
	/*
	protected Juggler removeJuggler(int n) {
		return (Juggler)jugglers.elementAt(n);
	}
	*/
	public void setJugglerCount(int jCount) {
		if (jCount<0) throw new RuntimeException("Cannot set juggler count to "+jCount);
		while (jugglers.size()<jCount) addJuggler();
		while (jugglers.size()>jCount) removeJuggler(getJuggler(jugglers.size()-1));;
	}
	/*
	protected Ball addBall() {
		Ball ball=new Ball(balls.size());
		balls.addElement(ball);
		return ball;
	}*/
/*	protected Ball getBall(int n) {
		Ball ball;
		if (n>balls.size()) throw new RuntimeException("n="+n+",balls.size()="+balls.size());
		if (n==balls.size()) {
			ball=new Ball(n);
			balls.addElement(ball);
		} else {
			ball=(Ball)balls.elementAt(n);
		}
		return ball;
	}
*/
	protected Ball getNewBall() {
		Ball ball=new Ball(ballCount);
		ballCount++;
		return ball;
	}
/*
	protected void allocateBalls(Hand hand,int count) {
	}
	protected void allocateBalls() {
		int n=0;
		for (int j=0;j<getJugglerCount();j++) {
			Juggler juggler=getJuggler(j);
			int jBalls=juggler.getBallCount();
			Ball[] ballArray=new Ball[jBalls];
			for (int i=0;i<jBalls;i++) {
				ballArray[i]=getBall(n+i);
			}
			juggler.setBalls(ballArray);
			n+=jBalls;
		}
		// remove unused balls!
		while (balls.size() > n) balls.removeElementAt(balls.size()-1);
	}
*/
	public int getMaxBeats() {
		return maxBeats;
	}
	protected void setMaxTime(int time) {
		this.maxTime=time;
	}
	public int getMaxTime() {
		return maxTime;// todo
	}
	public int getMaxPassTime() {
		return maxTime;// todo
	}
	public int getMaxCatchTime() {
		return maxTime;// todo
	}
	public Juggler getJuggler(int n) {
		if (n>=jugglers.size()) return null;
		return (Juggler)jugglers.elementAt(n);
	}
	public int getJugglerCount() {
		return jugglers.size();
	}
	public int getHandCount() {
		return jugglers.size()*2;
	}
	public int getBallCount() {
		int count=0;
		for (int h=0;h<getHandCount();h++) {
			count+=getHand(h).getBallCount();
		}
		return count;
	}
	public Hand getHand(int number) {
		Juggler j=(Juggler)jugglers.elementAt(number/2);
		if (number%2==0) return j.getRightHand();
		return j.getLeftHand();
	}
	
	/** @return The passing Endpoints - balls are in the air or not yet thrown again at this time */
	public Enumeration getPassingEndPoints(int time) {
		Vector endPoints=new Vector();
		for (int t=Math.max(0,time-getMaxBeats());t<=time;t++) {
			for (int h=0;h<getHandCount();h++) {
				EndPoint endPoint=getHand(h).getEndPoint(t);
				if (endPoint.isBeat() && !endPoint.getBall().noBall() && !endPoint.getPass().noPass() && (t+endPoint.getPass().getBeats())>time) endPoints.addElement(endPoint);
			}
		}
		return endPoints.elements();
	}
// used to copy passes
	static public EndPoint translatePass(EndPoint newPassPoint,Pass pass) {
		int catchTime=newPassPoint.getTime()+pass.getBeats();
		if (pass.isSelf()) {
			// not a pass
			if (pass.isRtoLorLtoR()) {
				return newPassPoint.getHand().getOther().getEndPoint(catchTime);
			}
			return newPassPoint.getHand().getEndPoint(newPassPoint.getTime()+pass.getBeats());
		} else {
			// find someone to pass to
			int relativeHand=pass.getToHand().getNumber()-pass.getFromHand().getNumber();
			Pattern pattern=newPassPoint.getHand().getJuggler().getPattern();
			Hand toHand=pattern.getHand((newPassPoint.getHand().getNumber()+relativeHand)%pattern.getHandCount());
			if (!toHand.getJuggler().equals(newPassPoint.getJuggler()) && toHand.isBeat(catchTime)) {
				return toHand.getEndPoint(catchTime);
			}
			// this won't do
			// try to find other jugglers
			Juggler juggler=newPassPoint.getJuggler();
			do {
				// get the next person
				juggler=(Juggler)pattern.jugglers.elementAt((pattern.jugglers.indexOf(juggler)+1)%pattern.jugglers.size());
				if (juggler.getLeftHand().isBeat(catchTime))
					return juggler.getLeftHand().getEndPoint(catchTime);
				if (juggler.getRightHand().isBeat(catchTime))
					return juggler.getRightHand().getEndPoint(catchTime);
			} while (!juggler.equals(newPassPoint.getJuggler()));
			return EndPoint.INVALID_ENDPOINT;
		}
	}
	public void write(Writer out) throws IOException {
		for (int j=0;j<getJugglerCount();j++) {
			out.write(getJuggler(j).getRightHand().getRhythm().toString());
			out.write(System.getProperty("line.separator"));
		}
	}
}
