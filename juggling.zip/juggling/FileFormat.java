package juggling;

import java.io.*;

public interface FileFormat {
	public Pattern readInputStream(InputStream input) throws IOException;
	public void writeOutputStream(OutputStream output,Pattern pattern) throws IOException;
}
