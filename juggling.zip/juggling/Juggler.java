package juggling;

import java.io.*;

public class Juggler {
	Pattern pattern;
	int number;
//	int ballCount=0;
	Hand leftHand;
	Hand rightHand;

/*
	Juggler(Hand leftHand,Hand rightHand) {
		this.leftHand=leftHand;
		this.rightHand=rightHand;
	}
*/
	Juggler(int number,Pattern pattern) {
		this.number=number;
		this.pattern=pattern;
		rightHand=new Hand(number*2,this,new Rhythm("x_"));
		leftHand=new Hand(number*2+1,this,new Rhythm("_x"));
/*
		if (synchro) {
			leftHand=new Hand(this,new Rhythm("x_"));
			for (int i=0;i<balls.length;i++) {
				if (i%2==0) rightHand.getEndPoint(2*(i/2)).setBall(balls[i]);
				else leftHand.getEndPoint(2*(i/2)).setBall(balls[i]);
			}
		} else {
*/
	}
	protected void setNumber(int number) {
		this.number=number;
		rightHand.setNumber(number*2);
		leftHand.setNumber(number*2+1);
	}
/*
	Juggler(Pattern pattern,Ball[] balls) {
		this.pattern=pattern;
		rightHand=new Hand(this,new Rhythm("x_"));
			leftHand=new Hand(this,new Rhythm("_x"));
			setStartingBalls(balls);
//		}
	}
*/
	public int getNumber() {
		return number;
	}
	public String getLabel() {
		return new StringBuffer("").append((char)('A'+number)).toString();
	}
	public int getBallCount() {
		return rightHand.getBallCount()+leftHand.getBallCount();
		//return ballCount;
	}
	/*
	public void setBallCount(int ballCount) {
		System.out.println("Setting ballCount="+ballCount);
		if (this.ballCount!=ballCount) {
			this.ballCount=ballCount;
			removeBalls();
			// pattern must assign balls
			pattern.allocateBalls();
		}
	}
	*/
	protected void removePasses() {
		rightHand.removePasses();
		leftHand.removePasses();
	}
	/*
	protected void removeBalls() {
		int balls=ballCount;
		for (int t=0;t<pattern.getMaxTime() && balls>0;t++) {
			// try right hand
			EndPoint rightHandEndPoint=rightHand.getEndPoint(t);
			if (rightHandEndPoint.isBeat()) {
				rightHandEndPoint.setBall(Ball.NO_BALL);
				balls--;
			}
			// then left hand
			EndPoint leftHandEndPoint=leftHand.getEndPoint(t);
			if (leftHandEndPoint.isBeat()) {
				leftHandEndPoint.setBall(Ball.NO_BALL);
				balls--;
			}
		}
	}
	// sets the balls that are held at the start of the pattern
	protected void setBalls(Ball[] balls) {
		for (int t=0,n=0;n<balls.length;t++) {
			// try right hand
			EndPoint rightHandEndPoint=rightHand.getEndPoint(t);
			if (rightHandEndPoint.isBeat()) {
				rightHandEndPoint.setBall(balls[n]);
				n++;
			}
			// then left hand
			EndPoint leftHandEndPoint=leftHand.getEndPoint(t);
			if (leftHandEndPoint.isBeat() && n<balls.length) {
				leftHandEndPoint.setBall(balls[n]);
				n++;
			}
		}
	}
	*/
	public Pattern getPattern() {
		return pattern;
	}
	public Hand getLeftHand() {
		return leftHand;
	}
	public Hand getRightHand() {
		return rightHand;
	}
	public void write(Writer out) throws IOException {
		out.write("juggler "+getLabel()+" {");
		out.write(System.getProperty("line.separator"));
		getRightHand().write(out);
		getLeftHand().write(out);
		out.write(System.getProperty("line.separator"));
		out.write("}");
		out.write(System.getProperty("line.separator"));
	}
}
