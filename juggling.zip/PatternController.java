import java.util.*;
import java.io.*;
import juggling.*;

public class PatternController extends Observable {

	static FileFormat fileFormat=new PatternFileFormat();
	static PassCollection clipboardPasses=PassCollection.EMPTY_COLLECTION;
	static int untitledCount=0;
	
	String filename;
	File patternFile;
	Pattern pattern;
	Stack undoStack=new Stack();
	Stack redoStack=new Stack();
	int changeCount=0;
	boolean multipleChanges=false;

	abstract class Change {
		int number;
		
		Change(int number) {
			this.number=number;
		}
		protected abstract void undo();
		protected abstract void redo();
	}
	class AddPassChange extends Change {
		EndPoint endPoint;
		Pass pass;
		AddPassChange(int number,EndPoint endPoint,Pass pass) {
			super(number);
			this.endPoint=endPoint;
			this.pass=pass;
		}
		protected void undo() {
			endPoint.removePass();
		}
		protected void redo() {
			endPoint.makePass(pass.getToHand().getEndPoint(endPoint.getTime()+pass.getBeats()));
		}
	}
	class RemovePassChange extends Change {
		EndPoint endPoint;
		Pass pass;
		RemovePassChange(int number,EndPoint endPoint,Pass pass) {
			super(number);
			this.endPoint=endPoint;
			this.pass=pass;
		}
		protected void undo() {
			endPoint.makePass(pass.getToHand().getEndPoint(endPoint.getTime()+pass.getBeats()));
		}
		protected void redo() {
			endPoint.removePass();
		}
	}
	
	public PatternController(Pattern pattern) {
		this.pattern=pattern;
	}
	public Pattern getPattern() {
		return pattern;
	}
	public void setFilename(String filename) {
		if (filename!=null) this.filename=filename;
	}
	public String getFilename() {
		if (filename==null) {
			untitledCount++;
			filename="untitled"+untitledCount;
		}
		return filename;
	}
	public File getFile() {
		return patternFile;
	}
	protected void setFile(File file) {
		this.patternFile=file;
		this.filename=file.getName();
		// reset undo redo
		undoStack.removeAllElements();
		redoStack.removeAllElements();
		changeCount=0;
	}
/*	public void readSiteswap(String siteswap) {
		pattern=SiteswapParser.readSiteswap(siteswap);
		this.filename=siteswap;
		setChanged();
		notifyObservers();
	}
*/
	public void openPattern(File file) throws IOException {
		Pattern pattern=fileFormat.readInputStream(new FileInputStream(file));
		this.pattern=pattern;
		setFile(file);
		setChanged();
		notifyObservers();
		/*
		FileInputStream input=new FileInputStream(file);
		PatternController patternController=new PatternController(pattern);
		SiteswapParser.openPattern(input,patternController.getPattern(),0);
		setFile(file);
		*/
	}
	public void savePattern(File file) throws IOException {
		fileFormat.writeOutputStream(new FileOutputStream(file),pattern);
		setFile(file);
		/*
		FileWriter fileWriter=new FileWriter(file);
		BufferedWriter bufferedWriter=new BufferedWriter(fileWriter);
		getPattern().write(bufferedWriter);
		bufferedWriter.flush();
		bufferedWriter.close();
		setFile(file);
		*/
	}
	public void savePattern() throws IOException {
		savePattern(patternFile);
	}
	public void removePasses(Enumeration endPoints) {
		int changeCount=getNextChangeCount();
		while (endPoints.hasMoreElements()) {
			Object o=endPoints.nextElement();
			if (!(o instanceof EndPoint)) throw new RuntimeException();
			EndPoint endPoint=(EndPoint)o;
			if (!endPoint.getPass().noPass()) {
				Pass pass=endPoint.removePass();
				registerChange(new RemovePassChange(changeCount,endPoint,pass));
			}
		}
		notifyObservers();
	}
	public void removePasses(PassCollection passes) {
		if (!passes.equals(clipboardPasses)) {
			int changeCount=getNextChangeCount();
			Enumeration enum=passes.elements();
			while (enum.hasMoreElements()) {
				PassCollection.PassElement element=(PassCollection.PassElement)enum.nextElement();
				Pass pass=element.getPass();
				if (!pass.noPass()) {
					EndPoint endPoint=element.getEndPoint();
					pass=endPoint.removePass();
					registerChange(new RemovePassChange(changeCount,endPoint,pass));
				}
			}
			notifyObservers();
		}
	}
	public void cutToClipboard(PassCollection passes) {
		if (!passes.equals(clipboardPasses)) {
			int changeCount=getNextChangeCount();
			Enumeration enum=passes.elements();
			while (enum.hasMoreElements()) {
				PassCollection.PassElement element=(PassCollection.PassElement)enum.nextElement();
				Pass pass=element.getPass();
				if (!pass.noPass()) {
					EndPoint endPoint=element.getEndPoint();
					pass=endPoint.removePass();
					registerChange(new RemovePassChange(changeCount,endPoint,pass));
				}
			}
			clipboardPasses=passes;
			setChanged(); // the clipboard has changed
			notifyObservers();
		}
	}
	public void copyToClipboard(PassCollection passes) {
		if (!passes.equals(clipboardPasses)) {
			clipboardPasses=passes;
			setChanged(); // the clipboard has changed
			notifyObservers();
		}
	}
	public PassCollection getClipboardData() {
		return clipboardPasses;
	}
	public void paste(PassCollection selectedPasses) {
		if (!selectedPasses.isEmpty()) {
			int changeCount=getNextChangeCount();
			EndPoint topLeft=selectedPasses.getEndPoint(0,0);
			int baseT=topLeft.getTime();
			int baseH=topLeft.getHand().getNumber();
			for (int t=0;t<clipboardPasses.getBeats();t++) {
				for (int h=0;h<clipboardPasses.getHands();h++) {
					Pass pass=clipboardPasses.getPass(t,h);
					if (!pass.noPass()) {
						System.out.println("Pasting pass="+pass);
						Hand passHand=pattern.getHand((baseH+h)%pattern.getHandCount());
						if (!passHand.isBeat(baseT+t)) {
							passHand=passHand.getOther();
						}
						//EndPoint pasteTo=pattern.getHand((baseH+h)%pattern.getHandCount()).getEndPoint(baseT+t);
						EndPoint pasteTo=passHand.getEndPoint(baseT+t);
						System.out.println("pasteTo EndPoint:"+pasteTo);
						if (pasteTo.isBeat()) {
							System.out.println("pasteTo isBeat()=true");
							EndPoint catchPoint=Pattern.translatePass(pasteTo,pass);
							if (catchPoint.isBeat()) {
								System.out.println("catchPoint isBeat()=true");
								Pass newPass=pasteTo.makePass(catchPoint);
								if (!newPass.noPass()) {
									registerChange(new AddPassChange(changeCount,pasteTo,newPass));
								} else {
									System.out.println("Failed to pass:passPoint="+pasteTo+",catchPoint="+catchPoint);
								}
							}
						}
					}
				}
			}
			notifyObservers();
		}
	}
		/*
	public void cutToClipboard(Enumeration endPoints) {
		Clipboard.getClipboard().clear();
		int changeCount=getNextChangeCount();
		while (endPoints.hasMoreElements()) {
			Object o=endPoints.nextElement();
			if (!(o instanceof EndPoint)) throw new RuntimeException();
			EndPoint endPoint=(EndPoint)o;
			if (!endPoint.getPass().noPass()) {
				Pass pass=endPoint.removePass();
				Clipboard.getClipboard().addData(endPoint,pass);
				registerChange(new RemovePassChange(changeCount,endPoint,pass));
			}
		}
		notifyObservers();
	}
	public void copyToClipboard(Enumeration endPoints) {
		Clipboard.getClipboard().clear();
		while (endPoints.hasMoreElements()) {
			Object o=endPoints.nextElement();
			if (!(o instanceof EndPoint)) throw new RuntimeException();
			EndPoint endPoint=(EndPoint)o;
			Pass pass=endPoint.getPass();
			if (!pass.noPass()) {
				Clipboard.getClipboard().addData(endPoint,pass);
			}
		}
	}
	*/
	public boolean isModified() {
		return (changeCount>0);
	}
	protected void startMultipleChanges() {
		getNextChangeCount();
		multipleChanges=true;
	}
	protected void finishMultipleChanges() {
		multipleChanges=false;
	}
	protected synchronized int getNextChangeCount() {
		if (!multipleChanges) changeCount++;
		return changeCount;
	}
	public boolean canUndo() {
		return !undoStack.isEmpty();
	}
	public boolean canRedo() {
		return !redoStack.isEmpty();
	}
	public void undo() {
		Change change=(Change)undoStack.pop();
		int n=change.number;
		change.undo();
		redoStack.push(change);
		while (!undoStack.isEmpty() && ((Change)undoStack.peek()).number==n) {
			change=(Change)undoStack.pop();
			change.undo();
			redoStack.push(change);
		}
		changeCount=n-1;
		setChanged();
		notifyObservers();
	}
	public void redo() {
		Change change=(Change)redoStack.pop();
		int n=change.number;
		change.redo();
		undoStack.push(change);
		while (!redoStack.isEmpty() && ((Change)redoStack.peek()).number==n) {
			change=(Change)redoStack.pop();
			change.redo();
			undoStack.push(change);
		}
		changeCount=n;
		setChanged();
		notifyObservers();
	}
	protected void registerChange(Change change) {
		if (!redoStack.isEmpty()) redoStack.clear();
		undoStack.push(change);
		setChanged();
	}
	public boolean removePass(EndPoint endPoint) {
		if (!endPoint.getPass().noPass()) {
			Pass pass=endPoint.removePass();
			registerChange(new RemovePassChange(getNextChangeCount(),endPoint,pass));
			notifyObservers();
			return true;
		}
		return false;
	}
	public boolean addPass(EndPoint from,EndPoint to) {
		Pass pass=from.makePass(to);
		if (!pass.noPass()) {
			registerChange(new AddPassChange(getNextChangeCount(),from,pass));
			notifyObservers();
			return true;
		}
		return false;
	}
	public void addJuggler() {
		pattern.addJuggler();
		setChanged();
		notifyObservers();
	}
	public boolean removeJuggler(int n) {
		Juggler juggler=pattern.getJuggler(n);
		if (juggler!=null) {
			pattern.removeJuggler(juggler);
			setChanged();
			notifyObservers();
			return true;
		}
		return false;
	}
	// todo remove this method when no longer used
	public void patternChanged() {
		setChanged();
		notifyObservers();
	}
}
