import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

import juggling.*;

public class JugglingApp extends Frame {

	LadderDiagram ladderDiagram;
	PatternController patternController;
	Observer patternObserver=new Observer() {
		public void update(Observable ob,Object o) {
			patternUpdate((PatternController)ob);
		}
	};
	// map PatternController to PatternMenuItem
	Hashtable controllers=new Hashtable();

	MenuBar menuBar=new MenuBar();
	
	Menu menuFile=new Menu("File");
	MenuItem menuNewPattern=new MenuItem("New pattern...");
	MenuItem menuSiteswap=new MenuItem("New siteswap...");
	MenuItem menuOpen=new MenuItem("Open...");
	MenuItem menuSave=new MenuItem("Save");
	MenuItem menuSaveAs=new MenuItem("Save as...");
	MenuItem menuExit=new MenuItem("Close");
	
	Menu menuEdit=new Menu("Edit");
	MenuItem menuUndo=new MenuItem("Undo");
	MenuItem menuRedo=new MenuItem("Redo");
	MenuItem menuCut=new MenuItem("Cut");
	MenuItem menuCopy=new MenuItem("Copy");
	MenuItem menuPaste=new MenuItem("Paste");
	MenuItem menuRemove=new MenuItem("Remove");

	Menu menuPattern=new Menu("Pattern");
	MenuItem menuPatternProperties=new MenuItem("Properties...");
	MenuItem menuPatternAnimate=new MenuItem("Animate...");
	
	JugglingApp(Pattern pattern) {
		super("Juggling Explorer");
		PatternController controller=new PatternController(pattern);
		ladderDiagram=new LadderDiagram(/*patternController*/);	
		setLayout(new GridLayout(1,1));
		ScrollPane scrollPane=new ScrollPane();
		scrollPane.add(ladderDiagram);
		add(scrollPane);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				doExit();
			}
		});
		menuBar.add(menuFile);
		menuFile.add(menuNewPattern);
		menuNewPattern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doNewPattern();
			}
		});
		menuFile.add(menuSiteswap);
		menuSiteswap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doOpenSiteswap();
			}
		});
		menuFile.add(menuOpen);
		menuOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doOpen();
			}
		});
		menuFile.add(menuSave);
		menuSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doSave();
			}
		});
		menuFile.add(menuSaveAs);
		menuSaveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doSaveAs();
			}
		});
		menuSaveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doSave();
			}
		});
		menuFile.add(menuExit);
		menuExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doExit();
			}
		});
		menuUndo.setShortcut(new MenuShortcut('u'));
		menuUndo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.undo();
			}
		});
		menuRedo.setShortcut(new MenuShortcut('r'));
		menuRedo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.redo();
			}
		});
		menuCut.setShortcut(new MenuShortcut('x'));
		menuCut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.cutToClipboard(ladderDiagram.getSelectionModel().getSelection());
			}
		});
		menuCopy.setShortcut(new MenuShortcut('c'));
		menuCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.copyToClipboard(ladderDiagram.getSelectionModel().getSelection());
			}
		});
		menuPaste.setShortcut(new MenuShortcut('v'));
		menuPaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.paste(ladderDiagram.getSelectionModel().getSelection());
			}
		});
		menuRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patternController.removePasses(ladderDiagram.getSelectionModel().getSelection());
			}
		});
		menuBar.add(menuEdit);
		menuEdit.add(menuUndo);
		menuEdit.add(menuRedo);
		menuEdit.add(menuCut);
		menuEdit.add(menuCopy);
		menuEdit.add(menuPaste);
		menuEdit.add(menuRemove);
		
		menuBar.add(menuPattern);
		menuPattern.add(menuPatternProperties);
		menuPatternProperties.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showPatternProperties();
			}
		});
		menuPattern.add(menuPatternAnimate);
		menuPatternAnimate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				animate();
			}
		});
		menuPattern.addSeparator();
		addController(controller);
		
		setMenuBar(menuBar);
		ladderDiagram.getSelectionModel().addObserver(new Observer() {
			public void update(Observable ob,Object o) {
				selectionUpdate((LadderDiagram.SelectionModel)ob);
			}
		});
		ladderDiagram.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				setSize(getPreferredSize());
				doLayout();
				validate();
			}
		});
		setController(controller);
		selectionUpdate(ladderDiagram.getSelectionModel());
		//patternUpdate(patternController);
		setSize(getPreferredSize());
	}
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}
	public Dimension getPreferredSize() {
		// try to size nicely
		Dimension ladderSize=ladderDiagram.getSize();
		Dimension maxSize=Toolkit.getDefaultToolkit().getScreenSize();
		addNotify(); // ensure peer is created to get correct insets
		Insets insets=getInsets();
		return new Dimension(Math.min(ladderSize.width+insets.left+insets.right+4,maxSize.width),Math.min(ladderSize.height+insets.top+insets.bottom+4,maxSize.height));
	}
/*	File[] getOpenFiles() {
		File[] files=new File[controllers.size()];
		return (File[])controllers.keySet().toArray(files);
	}
*/
	public void patternUpdate(PatternController patternController) {
		menuSave.setEnabled(patternController.isModified());
		menuUndo.setEnabled(patternController.canUndo());
		menuRedo.setEnabled(patternController.canRedo());
	/*
		// try to size nicely
		Dimension ladderSize=ladderDiagram.getSize();
		Dimension maxSize=Toolkit.getDefaultToolkit().getScreenSize();
		addNotify(); // ensure peer is created to get correct insets
		Insets insets=getInsets();
		Dimension newSize=new Dimension(Math.min(ladderSize.width+insets.left+insets.right+4,maxSize.width),Math.min(ladderSize.height+insets.top+insets.bottom+4,maxSize.height));
		if (!getSize().equals(newSize)) {
			setSize(newSize);
			repaint();
		}
		//setSize(Math.min(ladderSize.width+insets.left+insets.right+4,maxSize.width),Math.min(ladderSize.height+insets.top+insets.bottom+4,maxSize.height));
		*/
	}
	public void selectionUpdate(LadderDiagram.SelectionModel selectionModel) {
		boolean selected=selectionModel.isSelected();
		menuCut.setEnabled(selected);
		menuCopy.setEnabled(selected);
		menuPaste.setEnabled(selected);
		menuRemove.setEnabled(selected);
	}
/*	protected void addController(PatternController controller) {
		if (controller!=null && !controllers.contains(controller)) {
			controllers.addElement(controller);
			addPatternShortcut(file);
		}
	}
*/
	protected void setController(PatternController controller) {
		if (patternController!=null) patternController.deleteObserver(patternObserver);
		patternController=controller;
		if (patternController!=null) {
			patternController.addObserver(patternObserver);
			ladderDiagram.setController(controller);
			setTitle("Juggling Explorer - "+patternController.getFilename());
			patternUpdate(patternController);
		}
	}
	class PatternMenuItem extends MenuItem implements ActionListener {
		PatternController controller;
		PatternMenuItem(PatternController controller) {
			this.controller=controller;
			updateLabel();
			addActionListener(PatternMenuItem.this);
		}
		public void actionPerformed(ActionEvent e) {
			setController(controller);
		}
		public void updateLabel() {
			setLabel(controller.getFilename());
		}
	}
	protected void updatePatternName(PatternController controller) {
		PatternMenuItem menuItem=(PatternMenuItem)controllers.get(controller);
		menuItem.updateLabel();
		setTitle("Juggling Explorer - "+controller.getFilename());
	}
	protected void addController(PatternController controller) {
		MenuItem patternMenuItem=new PatternMenuItem(controller);
		controllers.put(controller,patternMenuItem);
		menuPattern.add(patternMenuItem);
	}
	private void doNewPattern() {
		PatternController controller=new PatternController(new Pattern());
		addController(controller);
		setController(controller);
		showPatternProperties();
	}
	private void doOpenSiteswap() {
		SiteswapDialog dialog=new SiteswapDialog(JugglingApp.this,true);
		dialog.setVisible(true);
		Pattern pattern=dialog.getPattern();
		if (pattern!=null) {
			PatternController controller=new PatternController(pattern);
			controller.setFilename(dialog.getSiteswap());
			addController(controller);
			setController(controller);
		}
		dialog.dispose();
	}
	private void doOpen() {
		FileDialog fileDialog=new FileDialog(this,"Open",FileDialog.LOAD);
		fileDialog.setVisible(true);
		if (fileDialog.getFile()!=null) {
			try {
				File file=new File(fileDialog.getDirectory(),fileDialog.getFile());
				PatternController patternController=new PatternController(new Pattern());
				patternController.openPattern(file);
				addController(patternController);
				setController(patternController);
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}
	}
	private void doSave() {
		if (patternController.getFile()!=null) {
			try {
				patternController.savePattern();
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		} else {
			doSaveAs();
		}
	}
	private void doSaveAs() {
		FileDialog fileDialog=new FileDialog(this,"Save",FileDialog.SAVE);
		// following line causes fault!
		//if (patternController.getFilename()!=null) fileDialog.setFile(patternController.getFilename());
		fileDialog.setVisible(true);
		if (fileDialog.getFile()!=null) {
			try {
				File file=new File(fileDialog.getDirectory(),fileDialog.getFile());
				patternController.savePattern(file);
				updatePatternName(patternController); // filename changed in menu
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}
	}
	private void doExit() {
		setVisible(false);
		System.exit(0);
	}
	private void animate() {
		Frame frame=new Frame("Pattern Animation");
		frame.setLayout(new GridLayout(1,1));
		PassingAnimation animation=new PassingAnimation(patternController.getPattern());
		animation.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				PassingAnimation anim=(PassingAnimation)e.getSource();
				if (anim.hasFinished()) anim.play();
				else anim.pause();
			}
		});
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				Frame theFrame=(Frame)e.getSource();
				theFrame.setVisible(false);
				theFrame.dispose();
			}
		});
		frame.add(animation);
		frame.setSize(300,350);
		frame.setVisible(true);
		animation.play();
	}
	private void showPatternProperties() {
		PatternProperties patternProperties=new PatternProperties(this,patternController);
		patternProperties.setVisible(true);
	}
	public static void main(String[] args) {
		try {
			Pattern pattern;
			if (args.length>0) {
				pattern=SiteswapParser.readSiteswap(args[0]);
			} else {
				// simple example
				pattern=SiteswapParser.readSiteswap("333");
			}
			JugglingApp app=new JugglingApp(pattern);
			app.setVisible(true);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
